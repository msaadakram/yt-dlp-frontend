import { useState, useRef, type FormEvent } from "react";
import { Link, RouterProvider } from "react-router";
import { router } from "./routes";
import { motion, AnimatePresence } from "motion/react";
import {
  Download,
  Music,
  Image,
  Video,
  ChevronDown,
  CheckCircle2,
  ArrowRight,
  Play,
  Zap,
  Shield,
  Globe,
  Star,
  Menu,
  X,
  Copy,
  Clock,
  Sparkles,
  MonitorPlay,
  Youtube,
  Facebook,
  Instagram,
  Twitter,
  Twitch,
  Linkedin,
  Rss,
  Music2,
  Clapperboard,
  Film,
  Camera,
  Ghost,
  Mail,
  LockKeyhole,
  Eye,
  EyeOff,
  ArrowLeft,
  Check,
  ShieldCheck,
  Github,
  BarChart2,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type DownloadType = "video" | "audio" | "thumbnail";
type Format = { label: string; ext: string; quality?: string };
type _Platform = { name: string; color: string; icon: typeof Youtube }; // kept for Dashboard imports
type PricingPlan = { name: string; price: string; period: string; features: string[]; cta: string; highlight: boolean };

// ─── Data ────────────────────────────────────────────────────────────────────

// ─── Brand SVG logos ─────────────────────────────────────────────────────────

type BrandLogoProps = { className?: string; style?: React.CSSProperties };

function YoutubeLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z" />
    </svg>
  );
}

function FacebookLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047v-2.66c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.264h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z" />
    </svg>
  );
}

function InstagramLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" />
    </svg>
  );
}

function TikTokLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-4.77-4.32V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.18 8.18 0 0 0 4.78 1.52V6.76a4.85 4.85 0 0 1-1.01-.07z" />
    </svg>
  );
}

function XLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

function VimeoLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M23.977 6.416c-.105 2.338-1.739 5.543-4.894 9.609-3.268 4.247-6.026 6.37-8.29 6.37-1.409 0-2.578-1.294-3.553-3.881L5.322 11.4C4.603 8.816 3.834 7.522 3.01 7.522c-.179 0-.806.378-1.881 1.132L0 7.197c1.185-1.044 2.351-2.084 3.501-3.128C5.08 2.701 6.266 1.984 7.055 1.91c1.867-.18 3.016 1.1 3.447 3.838.465 2.953.789 4.789.971 5.507.539 2.45 1.131 3.674 1.776 3.674.502 0 1.256-.796 2.265-2.385 1.004-1.589 1.54-2.797 1.612-3.628.144-1.371-.395-2.061-1.612-2.061-.574 0-1.167.121-1.777.391 1.186-3.868 3.434-5.757 6.762-5.637 2.473.06 3.628 1.664 3.478 4.807z" />
    </svg>
  );
}

function DailymotionLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M12.006 0C5.373 0 0 5.372 0 12.006 0 18.63 5.373 24 12.006 24 18.63 24 24 18.63 24 12.006 24 5.372 18.63 0 12.006 0zm3.917 16.947a5.056 5.056 0 0 1-3.242 1.166c-2.797 0-5.066-2.268-5.066-5.066 0-2.797 2.27-5.066 5.066-5.066 1.014 0 1.959.3 2.748.813V6.87h2.355v10.027h-1.861v-.95zm-3.242-6.756a2.857 2.857 0 1 0 0 5.715 2.857 2.857 0 0 0 0-5.715z" />
    </svg>
  );
}

function TwitchLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714z" />
    </svg>
  );
}

function RedditLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z" />
    </svg>
  );
}

function PinterestLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 0 1 .083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12.017 24c6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z" />
    </svg>
  );
}

function LinkedInLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

function SnapchatLogo({ className, style }: BrandLogoProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor">
      <path d="M12.206.793c.99 0 4.347.276 5.93 3.821.529 1.193.403 3.219.299 4.847l-.003.06c-.012.18-.022.345-.03.51.075.045.203.09.401.09.3-.016.659-.12 1.033-.301.165-.088.344-.104.464-.104.182 0 .359.029.509.09.45.149.734.479.734.838.015.449-.39.839-1.213 1.168-.089.029-.209.075-.344.119-.45.135-1.139.36-1.333.81-.09.224-.061.524.12.868l.015.015c.06.136 1.526 3.475 4.791 4.014.255.044.435.27.42.509 0 .075-.015.149-.045.225-.24.569-1.273.988-3.146 1.271-.059.091-.12.375-.164.57-.029.179-.074.36-.134.553-.076.271-.27.405-.555.405h-.03c-.135 0-.313-.031-.538-.074-.36-.075-.765-.135-1.273-.135-.3 0-.599.015-.913.074-.6.104-1.123.464-1.723.884-.853.599-1.826 1.288-3.294 1.288-.06 0-.119-.015-.18-.015h-.149c-1.468 0-2.427-.675-3.279-1.288-.599-.42-1.107-.779-1.707-.884-.314-.045-.629-.074-.928-.074-.54 0-.958.089-1.272.149-.211.043-.391.074-.54.074-.374 0-.523-.224-.583-.42-.061-.192-.09-.389-.135-.567-.046-.181-.105-.494-.166-.57-1.918-.222-2.95-.642-3.189-1.226-.031-.063-.045-.15-.045-.226.014-.27.195-.465.42-.509 3.264-.54 4.73-3.879 4.791-4.02l.016-.029c.18-.345.224-.645.119-.869-.195-.434-.884-.658-1.332-.809-.121-.029-.24-.074-.346-.119-1.107-.435-1.257-.93-1.197-1.273.09-.479.674-.793 1.168-.793.146 0 .27.029.383.074.42.194.789.3 1.104.3.234 0 .384-.06.465-.105l-.046-.569c-.098-1.626-.225-3.651.304-4.837C7.392 1.077 10.739.807 11.727.807l.419-.015h.06z" />
    </svg>
  );
}

type BrandPlatform = {
  name: string;
  bg: string;
  fg: string;
  Logo: React.ComponentType<BrandLogoProps>;
};

const platforms: BrandPlatform[] = [
  { name: "YouTube",     bg: "#FF0000", fg: "#ffffff", Logo: YoutubeLogo },
  { name: "Facebook",    bg: "#1877F2", fg: "#ffffff", Logo: FacebookLogo },
  { name: "Instagram",   bg: "#E1306C", fg: "#ffffff", Logo: InstagramLogo },
  { name: "TikTok",      bg: "#010101", fg: "#ffffff", Logo: TikTokLogo },
  { name: "Twitter / X", bg: "#14171A", fg: "#ffffff", Logo: XLogo },
  { name: "Vimeo",       bg: "#1AB7EA", fg: "#ffffff", Logo: VimeoLogo },
  { name: "Dailymotion", bg: "#0066DC", fg: "#ffffff", Logo: DailymotionLogo },
  { name: "Twitch",      bg: "#9146FF", fg: "#ffffff", Logo: TwitchLogo },
  { name: "Reddit",      bg: "#FF4500", fg: "#ffffff", Logo: RedditLogo },
  { name: "Pinterest",   bg: "#E60023", fg: "#ffffff", Logo: PinterestLogo },
  { name: "LinkedIn",    bg: "#0A66C2", fg: "#ffffff", Logo: LinkedInLogo },
  { name: "Snapchat",    bg: "#FFFC00", fg: "#000000", Logo: SnapchatLogo },
];

const videoFormats: Format[] = [
  { label: "MP4 • 4K Ultra HD", ext: "mp4", quality: "2160p" },
  { label: "MP4 • Full HD", ext: "mp4", quality: "1080p" },
  { label: "MP4 • HD", ext: "mp4", quality: "720p" },
  { label: "MP4 • Standard", ext: "mp4", quality: "480p" },
  { label: "WebM • HD", ext: "webm", quality: "720p" },
  { label: "MKV • Full HD", ext: "mkv", quality: "1080p" },
];

const audioFormats: Format[] = [
  { label: "MP3 • 320 kbps", ext: "mp3" },
  { label: "MP3 • 192 kbps", ext: "mp3" },
  { label: "AAC • 256 kbps", ext: "aac" },
  { label: "FLAC • Lossless", ext: "flac" },
  { label: "WAV • Uncompressed", ext: "wav" },
  { label: "OGG • 192 kbps", ext: "ogg" },
];

const thumbnailFormats: Format[] = [
  { label: "JPG • Maximum", ext: "jpg", quality: "maxresdefault" },
  { label: "JPG • HQ", ext: "jpg", quality: "hqdefault" },
  { label: "PNG • Maximum", ext: "png", quality: "maxresdefault" },
  { label: "WebP • Optimized", ext: "webp", quality: "maxresdefault" },
];

const steps = [
  {
    number: "01",
    title: "Paste the URL",
    desc: "Copy any video link from YouTube, Facebook, TikTok or 200+ other platforms and paste it into the input above.",
    icon: Copy,
  },
  {
    number: "02",
    title: "Choose format & quality",
    desc: "Select your preferred format — MP4, MP3, FLAC, WebP — and the quality level that suits your needs.",
    icon: Sparkles,
  },
  {
    number: "03",
    title: "Download instantly",
    desc: "Click Download and your file is processed and delivered in seconds. No account required.",
    icon: Zap,
  },
];

const features = [
  { icon: Globe, title: "200+ Supported Platforms", desc: "From YouTube to niche platforms. If there's a video, we can fetch it." },
  { icon: Zap, title: "Blazing Fast Processing", desc: "Server-side conversion with CDN delivery. Your download starts in under 3 seconds." },
  { icon: Shield, title: "Private & Secure", desc: "We don't store your URLs or files. Everything is processed ephemerally and deleted immediately." },
  { icon: MonitorPlay, title: "Any Quality, Any Format", desc: "4K, 1080p, 720p video. Lossless FLAC and 320 kbps MP3 audio. PNG and WebP thumbnails." },
  { icon: Clock, title: "No Queue, No Wait", desc: "Pro plans process in parallel. No waiting in line — start the next download immediately." },
  { icon: Star, title: "Batch Downloads", desc: "Download entire playlists or channels in one click with our Pro and Team plans." },
];

const plans: PricingPlan[] = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    features: ["10 downloads / day", "Up to 1080p video", "MP3 & MP4 formats", "Standard processing speed", "50+ platforms supported"],
    cta: "Get Started Free",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$9",
    period: "per month",
    features: ["Unlimited downloads", "4K Ultra HD video", "All formats incl. FLAC & WebP", "Priority processing", "200+ platforms supported", "Batch playlist downloads", "No ads"],
    cta: "Start Pro Trial",
    highlight: true,
  },
  {
    name: "Team",
    price: "$29",
    period: "per month",
    features: ["Everything in Pro", "5 team seats", "API access", "Webhook notifications", "Priority email support", "Custom retention (30 days)"],
    cta: "Contact Sales",
    highlight: false,
  },
];

// ─── Animation helpers ────────────────────────────────────────────────────────

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0 },
};

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.08 } },
};

function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-80px" }}
      variants={fadeUp}
      transition={{ duration: 0.55, ease: [0.21, 0.6, 0.35, 1], delay }}
    >
      {children}
    </motion.div>
  );
}

// ─── Components ───────────────────────────────────────────────────────────────

function Nav({ menuOpen, setMenuOpen }: { menuOpen: boolean; setMenuOpen: (v: boolean) => void }) {
  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-b border-border"
    >
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <motion.div whileHover={{ scale: 1.03 }}>
          <Link to="/" className="flex items-center gap-2" aria-label="fetchwave home">
            <div className="w-8 h-8 rounded-lg bg-[#0d1f26] flex items-center justify-center">
              <Download className="w-4 h-4 text-[#5baab8]" />
            </div>
            <span className="font-bold text-lg tracking-tight text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              fetchwave
            </span>
          </Link>
        </motion.div>

        <nav className="hidden md:flex items-center gap-8">
          {[["Features", "#"], ["Platforms", "#"], ["Pricing", "/pricing"], ["API", "/api"]].map(([label, href]) => (
            href.startsWith("/") ? (
              <Link key={label} to={href} className="relative text-sm font-medium text-muted-foreground hover:text-foreground transition-colors group" style={{ fontFamily: "'Inter', sans-serif" }}>
                {label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#5baab8] group-hover:w-full transition-all duration-300" />
              </Link>
            ) : (
              <a key={label} href={href} className="relative text-sm font-medium text-muted-foreground hover:text-foreground transition-colors group" style={{ fontFamily: "'Inter', sans-serif" }}>
                {label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#5baab8] group-hover:w-full transition-all duration-300" />
              </a>
            )
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <Link to="/dashboard" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors px-4 py-2 flex items-center gap-1.5" style={{ fontFamily: "'Inter', sans-serif" }}>
            <BarChart2 className="w-3.5 h-3.5" /> Dashboard
          </Link>
          <Link to="/sign-in" className="text-sm font-medium text-foreground hover:text-accent transition-colors px-4 py-2" style={{ fontFamily: "'Inter', sans-serif" }}>
            Sign in
          </Link>
          <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}>
            <Link to="/sign-up" className="block text-sm font-semibold bg-[#0d1f26] text-white px-5 py-2.5 rounded-full hover:bg-[#1a3545] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
              Start Free
            </Link>
          </motion.div>
        </div>

        <button className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden bg-white border-t border-border overflow-hidden"
          >
            <div className="px-6 py-4 flex flex-col gap-4">
              {[["Features", "#"], ["Platforms", "#"], ["Pricing", "/pricing"], ["API", "/api"]].map(([label, href]) => (
                href.startsWith("/") ? (
                  <Link key={label} to={href} onClick={() => setMenuOpen(false)} className="text-sm font-medium text-foreground py-1">{label}</Link>
                ) : (
                  <a key={label} href={href} className="text-sm font-medium text-foreground py-1">{label}</a>
                )
              ))}
              <div className="flex items-center gap-3 pt-1">
                <Link to="/sign-in" onClick={() => setMenuOpen(false)} className="text-sm font-medium text-foreground px-2 py-3">Sign in</Link>
                <Link to="/sign-up" onClick={() => setMenuOpen(false)} className="flex-1 text-sm font-semibold bg-[#0d1f26] text-white px-5 py-3 rounded-full text-center">Start Free</Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}

function Hero() {
  const [url, setUrl] = useState("");
  const [activeType, setActiveType] = useState<DownloadType>("video");
  const [selectedFormat, setSelectedFormat] = useState(0);
  const [showFormats, setShowFormats] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const formats = activeType === "video" ? videoFormats : activeType === "audio" ? audioFormats : thumbnailFormats;
  const typeConfig = {
    video: { icon: Video, label: "Video" },
    audio: { icon: Music, label: "Audio" },
    thumbnail: { icon: Image, label: "Thumbnail" },
  };

  function handleDownload() {
    if (!url.trim()) {
      inputRef.current?.focus();
      return;
    }
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      setDone(true);
      setTimeout(() => setDone(false), 3000);
    }, 2200);
  }

  return (
    <section className="pt-32 pb-20 px-6 relative overflow-hidden">
      {/* Animated background blobs */}
      <motion.div
        className="absolute top-0 right-0 w-[600px] h-[600px] rounded-full opacity-30 pointer-events-none"
        style={{ background: "radial-gradient(circle, #5baab8 0%, transparent 70%)" }}
        animate={{ x: ["30%", "20%", "30%"], y: ["-30%", "-20%", "-30%"], scale: [1, 1.1, 1] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full opacity-20 pointer-events-none"
        style={{ background: "radial-gradient(circle, #a8d4dc 0%, transparent 70%)" }}
        animate={{ x: ["-40%", "-30%", "-40%"], y: ["40%", "30%", "40%"], scale: [1, 1.15, 1] }}
        transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="max-w-4xl mx-auto relative">
        <motion.div className="flex justify-center mb-6" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <span
            className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase px-4 py-2 rounded-full bg-white border border-border text-muted-foreground shadow-sm"
            style={{ fontFamily: "'DM Mono', monospace" }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#5baab8] animate-pulse" />
            200+ platforms supported
          </span>
        </motion.div>

        <motion.h1
          className="text-center text-5xl md:text-7xl font-extrabold leading-[1.08] tracking-tight text-foreground mb-6"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.6 }}
        >
          Download any video,
          <br />
          <span className="text-[#5baab8]">audio</span> or thumbnail.
        </motion.h1>

        <motion.p
          className="text-center text-lg text-muted-foreground max-w-xl mx-auto mb-12 leading-relaxed"
          style={{ fontFamily: "'Inter', sans-serif" }}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.6 }}
        >
          Paste a link from YouTube, Facebook, TikTok, Instagram and 200+ more. Get your file in seconds — no account required.
        </motion.p>

        {/* Type switcher */}
        <motion.div className="flex justify-center mb-5" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
          <div className="inline-flex bg-white border border-border rounded-full p-1 shadow-sm gap-1 relative">
            {(["video", "audio", "thumbnail"] as DownloadType[]).map((type) => {
              const cfg = typeConfig[type];
              const Icon = cfg.icon;
              const active = activeType === type;
              return (
                <button
                  key={type}
                  onClick={() => {
                    setActiveType(type);
                    setSelectedFormat(0);
                  }}
                  className={`relative flex items-center gap-2 px-5 py-2 rounded-full text-sm font-semibold transition-colors ${
                    active ? "text-white" : "text-muted-foreground hover:text-foreground"
                  }`}
                  style={{ fontFamily: "'Inter', sans-serif" }}
                >
                  {active && (
                    <motion.span layoutId="typePill" className="absolute inset-0 bg-[#0d1f26] rounded-full shadow-md" transition={{ type: "spring", stiffness: 400, damping: 32 }} />
                  )}
                  <Icon className="w-3.5 h-3.5 relative z-10" />
                  <span className="relative z-10">{cfg.label}</span>
                </button>
              );
            })}
          </div>
        </motion.div>

        {/* Download card */}
        <motion.div
          className="bg-white rounded-2xl shadow-xl border border-border p-3 md:p-4"
          initial={{ opacity: 0, y: 24, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <div className="flex flex-col md:flex-row gap-3">
            <div className="flex-1 flex items-center gap-3 bg-[#eef6f8] rounded-xl px-4 py-3 focus-within:ring-2 focus-within:ring-[#5baab8]/40 transition-all">
              <Play className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <input
                ref={inputRef}
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleDownload()}
                placeholder="Paste your video URL here..."
                className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
                style={{ fontFamily: "'Inter', sans-serif" }}
              />
              {url && (
                <button onClick={() => setUrl("")} className="text-muted-foreground hover:text-foreground transition-colors">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="relative">
              <button
                onClick={() => setShowFormats(!showFormats)}
                className="flex items-center gap-2 bg-[#eef6f8] hover:bg-[#d4ecf0] rounded-xl px-4 py-3 text-sm font-medium text-foreground transition-colors whitespace-nowrap w-full md:w-auto"
                style={{ fontFamily: "'Inter', sans-serif" }}
              >
                <span className="text-xs font-bold uppercase tracking-widest text-[#5baab8]" style={{ fontFamily: "'DM Mono', monospace" }}>
                  {formats[selectedFormat].ext.toUpperCase()}
                </span>
                <span className="text-muted-foreground">{formats[selectedFormat].quality || formats[selectedFormat].label.split("•")[1]?.trim()}</span>
                <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${showFormats ? "rotate-180" : ""}`} />
              </button>

              <AnimatePresence>
                {showFormats && (
                  <motion.div
                    initial={{ opacity: 0, y: -8, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -8, scale: 0.96 }}
                    transition={{ duration: 0.18 }}
                    className="absolute top-full left-0 right-0 md:left-auto md:right-0 mt-2 bg-white rounded-xl border border-border shadow-xl z-20 overflow-hidden min-w-[220px]"
                  >
                    {formats.map((fmt, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          setSelectedFormat(i);
                          setShowFormats(false);
                        }}
                        className={`w-full flex items-center justify-between px-4 py-3 text-sm hover:bg-muted transition-colors text-left ${
                          i === selectedFormat ? "bg-[#eef6f8] font-semibold" : ""
                        }`}
                        style={{ fontFamily: "'Inter', sans-serif" }}
                      >
                        <span>{fmt.label}</span>
                        {i === selectedFormat && <CheckCircle2 className="w-4 h-4 text-[#5baab8]" />}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <motion.button
              onClick={handleDownload}
              disabled={processing}
              whileHover={{ scale: processing ? 1 : 1.03 }}
              whileTap={{ scale: processing ? 1 : 0.97 }}
              className="flex items-center justify-center gap-2 bg-[#0d1f26] hover:bg-[#1a3545] text-white font-semibold text-sm px-7 py-3 rounded-xl transition-colors disabled:opacity-70 whitespace-nowrap min-w-[150px]"
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              <AnimatePresence mode="wait">
                {processing ? (
                  <motion.span key="proc" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Processing...
                  </motion.span>
                ) : done ? (
                  <motion.span key="done" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#5baab8]" />
                    Ready!
                  </motion.span>
                ) : (
                  <motion.span key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    Download
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>
          </div>
        </motion.div>

        <motion.p
          className="text-center text-xs text-muted-foreground mt-5"
          style={{ fontFamily: "'Inter', sans-serif" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          Free to use · No sign-up required · Files deleted instantly after download
        </motion.p>
      </div>
    </section>
  );
}

function PlatformGrid() {
  return (
    <section className="py-16 px-6">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <p className="text-center text-xs font-semibold tracking-widest uppercase text-muted-foreground mb-8" style={{ fontFamily: "'DM Mono', monospace" }}>
            Works with all major platforms
          </p>
        </Reveal>
        <motion.div
          className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3"
          variants={stagger}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {platforms.map((p) => (
            <motion.div
              key={p.name}
              variants={fadeUp}
              whileHover={{ y: -6, scale: 1.03 }}
              className="group bg-white border border-border rounded-2xl p-4 flex flex-col items-center gap-2.5 hover:border-[#5baab8] hover:shadow-lg transition-all cursor-default"
            >
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center shadow-md transition-transform group-hover:scale-110"
                style={{ backgroundColor: p.bg }}
              >
                <p.Logo className="w-6 h-6" style={{ color: p.fg }} />
              </div>
              <span
                className="text-[10px] font-semibold text-muted-foreground text-center leading-tight group-hover:text-foreground transition-colors"
                style={{ fontFamily: "'Inter', sans-serif" }}
              >
                {p.name}
              </span>
            </motion.div>
          ))}
        </motion.div>
        <Reveal delay={0.1}>
          <div className="text-center mt-6">
            <button className="inline-flex items-center gap-2 text-sm font-medium text-[#5baab8] hover:text-[#3d8fa0] transition-colors group" style={{ fontFamily: "'Inter', sans-serif" }}>
              View all 200+ supported sites <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function HowItWorks() {
  return (
    <section className="py-20 px-6">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <div className="bg-[#0d1f26] rounded-3xl p-10 md:p-16 text-white relative overflow-hidden">
            <motion.div
              className="absolute -top-20 -right-20 w-72 h-72 rounded-full opacity-20"
              style={{ background: "radial-gradient(circle, #5baab8 0%, transparent 70%)" }}
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 10, repeat: Infinity }}
            />
            <div className="text-center mb-14 relative">
              <p className="text-[#5baab8] text-xs font-semibold tracking-widest uppercase mb-3" style={{ fontFamily: "'DM Mono', monospace" }}>
                Simple process
              </p>
              <h2 className="text-3xl md:text-5xl font-extrabold leading-tight tracking-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                Three steps to your file.
              </h2>
            </div>

            <motion.div className="grid md:grid-cols-3 gap-8 md:gap-10 relative" variants={stagger} initial="hidden" whileInView="visible" viewport={{ once: true }}>
              {steps.map((step, i) => {
                const Icon = step.icon;
                return (
                  <motion.div key={i} variants={fadeUp} className="flex flex-col gap-4">
                    <div className="flex items-start gap-4">
                      <span className="text-5xl font-extrabold text-white/10 leading-none select-none" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                        {step.number}
                      </span>
                      <div className="w-10 h-10 rounded-xl bg-[#5baab8]/20 flex items-center justify-center mt-1 flex-shrink-0">
                        <Icon className="w-5 h-5 text-[#5baab8]" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                        {step.title}
                      </h3>
                      <p className="text-sm text-white/60 leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}>
                        {step.desc}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Features() {
  return (
    <section className="py-20 px-6">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <div className="text-center mb-14">
            <p className="text-[#5baab8] text-xs font-semibold tracking-widest uppercase mb-3" style={{ fontFamily: "'DM Mono', monospace" }}>
              Why fetchwave
            </p>
            <h2 className="text-3xl md:text-5xl font-extrabold text-foreground tracking-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              Everything you need,
              <br />
              nothing you don&#39;t.
            </h2>
          </div>
        </Reveal>

        <motion.div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5" variants={stagger} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-60px" }}>
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <motion.div
                key={i}
                variants={fadeUp}
                whileHover={{ y: -6 }}
                className="bg-white border border-border rounded-2xl p-6 flex flex-col gap-4 hover:border-[#5baab8] hover:shadow-lg transition-all group"
              >
                <div className="w-11 h-11 rounded-xl bg-[#eef6f8] group-hover:bg-[#d4ecf0] flex items-center justify-center transition-colors group-hover:scale-110 duration-300">
                  <Icon className="w-5 h-5 text-[#5baab8]" />
                </div>
                <div>
                  <h3 className="font-bold text-foreground mb-1.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    {f.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}>
                    {f.desc}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}

function FormatShowcase() {
  const [activeTab, setActiveTab] = useState<DownloadType>("video");
  const tabs: { key: DownloadType; label: string; icon: typeof Video }[] = [
    { key: "video", label: "Video", icon: Video },
    { key: "audio", label: "Audio", icon: Music },
    { key: "thumbnail", label: "Thumbnail", icon: Image },
  ];
  const currentFormats = activeTab === "video" ? videoFormats : activeTab === "audio" ? audioFormats : thumbnailFormats;

  return (
    <section className="py-20 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <Reveal>
            <div>
              <p className="text-[#5baab8] text-xs font-semibold tracking-widest uppercase mb-3" style={{ fontFamily: "'DM Mono', monospace" }}>
                Format library
              </p>
              <h2 className="text-3xl md:text-4xl font-extrabold text-foreground tracking-tight mb-4 leading-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                Every format.
                <br />
                Every quality.
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-8" style={{ fontFamily: "'Inter', sans-serif" }}>
                From 4K Ultra HD video to lossless FLAC audio to maximum-resolution thumbnails — fetchwave handles every output format with zero quality loss.
              </p>
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
                className="inline-flex items-center gap-2 bg-[#0d1f26] text-white font-semibold text-sm px-6 py-3 rounded-full hover:bg-[#1a3545] transition-colors"
                style={{ fontFamily: "'Inter', sans-serif" }}
              >
                Start Downloading <ArrowRight className="w-4 h-4" />
              </motion.button>
            </div>
          </Reveal>

          <Reveal delay={0.15}>
            <div className="bg-white border border-border rounded-2xl overflow-hidden shadow-lg">
              <div className="flex border-b border-border relative">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  const active = activeTab === tab.key;
                  return (
                    <button
                      key={tab.key}
                      onClick={() => setActiveTab(tab.key)}
                      className={`relative flex-1 flex items-center justify-center gap-2 py-3.5 text-sm font-semibold transition-colors ${
                        active ? "text-[#0d1f26]" : "text-muted-foreground hover:text-foreground"
                      }`}
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {tab.label}
                      {active && <motion.span layoutId="tabUnderline" className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0d1f26]" />}
                    </button>
                  );
                })}
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, x: 12 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -12 }}
                  transition={{ duration: 0.2 }}
                  className="divide-y divide-border"
                >
                  {currentFormats.map((fmt, i) => (
                    <div key={i} className="flex items-center justify-between px-5 py-4 hover:bg-[#eef6f8] transition-colors group">
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-bold text-[#5baab8] uppercase w-10" style={{ fontFamily: "'DM Mono', monospace" }}>
                          {fmt.ext}
                        </span>
                        <span className="text-sm text-foreground font-medium" style={{ fontFamily: "'Inter', sans-serif" }}>
                          {fmt.label}
                        </span>
                      </div>
                      <button className="opacity-0 group-hover:opacity-100 flex items-center gap-1.5 text-xs font-semibold text-[#0d1f26] bg-[#d4ecf0] px-3 py-1.5 rounded-full transition-all">
                        <Download className="w-3 h-3" /> Select
                      </button>
                    </div>
                  ))}
                </motion.div>
              </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const reviews = [
    { name: "Sarah K.", role: "Content Creator", avatar: "SK", text: "I use fetchwave every day to archive my favorite YouTube tutorials. The 4K quality is genuinely lossless — I can't tell the difference from the original.", stars: 5 },
    { name: "Marcus T.", role: "Podcast Producer", avatar: "MT", text: "The FLAC audio extraction is the best I've found. Pulls a perfect lossless audio track from any video source in seconds. Absolute game changer.", stars: 5 },
    { name: "Lena M.", role: "Social Media Manager", avatar: "LM", text: "Batch downloading entire playlists saves me hours every week. The thumbnail downloader alone is worth the Pro subscription.", stars: 5 },
  ];

  return (
    <section className="py-20 px-6">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <p className="text-center text-xs font-semibold tracking-widest uppercase text-muted-foreground mb-3" style={{ fontFamily: "'DM Mono', monospace" }}>
            Trusted by creators
          </p>
          <h2 className="text-center text-3xl md:text-4xl font-extrabold text-foreground tracking-tight mb-12" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Loved by 500,000+ users.
          </h2>
        </Reveal>

        <motion.div className="grid md:grid-cols-3 gap-5" variants={stagger} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-60px" }}>
          {reviews.map((r, i) => (
            <motion.div key={i} variants={fadeUp} whileHover={{ y: -6 }} className="bg-white border border-border rounded-2xl p-6 flex flex-col gap-4 hover:shadow-lg transition-shadow">
              <div className="flex gap-1">
                {Array.from({ length: r.stars }).map((_, s) => (
                  <Star key={s} className="w-4 h-4 fill-[#5baab8] text-[#5baab8]" />
                ))}
              </div>
              <p className="text-sm text-foreground leading-relaxed flex-1" style={{ fontFamily: "'Inter', sans-serif" }}>
                &ldquo;{r.text}&rdquo;
              </p>
              <div className="flex items-center gap-3 pt-2 border-t border-border">
                <div className="w-9 h-9 rounded-full bg-[#d4ecf0] text-[#0d1f26] text-xs font-bold flex items-center justify-center">{r.avatar}</div>
                <div>
                  <p className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    {r.name}
                  </p>
                  <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>
                    {r.role}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function Pricing() {
  const [annual, setAnnual] = useState(false);

  return (
    <section className="py-20 px-6" id="pricing">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <div className="text-center mb-12">
            <p className="text-[#5baab8] text-xs font-semibold tracking-widest uppercase mb-3" style={{ fontFamily: "'DM Mono', monospace" }}>
              Pricing
            </p>
            <h2 className="text-3xl md:text-5xl font-extrabold text-foreground tracking-tight mb-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              Simple, honest pricing.
            </h2>

            <div className="inline-flex items-center gap-3">
              <span className="text-sm text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>
                Monthly
              </span>
              <button onClick={() => setAnnual(!annual)} className={`relative w-11 h-6 rounded-full transition-colors ${annual ? "bg-[#0d1f26]" : "bg-muted"}`}>
                <motion.span className="absolute top-1 w-4 h-4 rounded-full bg-white shadow" animate={{ left: annual ? 24 : 4 }} transition={{ type: "spring", stiffness: 500, damping: 30 }} />
              </button>
              <span className="text-sm text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>
                Annual <span className="text-[#5baab8] font-semibold">-20%</span>
              </span>
            </div>
          </div>
        </Reveal>

        <motion.div className="grid md:grid-cols-3 gap-5" variants={stagger} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-60px" }}>
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              whileHover={{ y: -8 }}
              className={`rounded-2xl p-7 flex flex-col gap-5 border transition-shadow ${
                plan.highlight ? "bg-[#0d1f26] border-[#0d1f26] shadow-2xl" : "bg-white border-border hover:border-[#5baab8] hover:shadow-md"
              }`}
            >
              {plan.highlight && (
                <span className="self-start text-[10px] font-bold tracking-widest uppercase bg-[#5baab8]/20 text-[#5baab8] px-3 py-1 rounded-full" style={{ fontFamily: "'DM Mono', monospace" }}>
                  Most Popular
                </span>
              )}

              <div>
                <p className={`text-sm font-semibold mb-1 ${plan.highlight ? "text-white/60" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>
                  {plan.name}
                </p>
                <div className="flex items-baseline gap-1">
                  <span className={`text-4xl font-extrabold tracking-tight ${plan.highlight ? "text-white" : "text-foreground"}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    {plan.price === "$9" && annual ? "$7" : plan.price === "$29" && annual ? "$23" : plan.price}
                  </span>
                  <span className={`text-sm ${plan.highlight ? "text-white/50" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>
                    /{plan.period}
                  </span>
                </div>
              </div>

              <ul className="flex flex-col gap-2.5 flex-1">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5 text-[#5baab8]" />
                    <span className={`text-sm leading-tight ${plan.highlight ? "text-white/80" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>
                      {feat}
                    </span>
                  </li>
                ))}
              </ul>

              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className={`w-full py-3.5 rounded-xl font-semibold text-sm transition-colors ${
                  plan.highlight ? "bg-[#5baab8] hover:bg-[#3d8fa0] text-white" : "bg-[#0d1f26] hover:bg-[#1a3545] text-white"
                }`}
                style={{ fontFamily: "'Inter', sans-serif" }}
              >
                {plan.cta}
              </motion.button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="py-16 px-6">
      <div className="max-w-5xl mx-auto">
        <Reveal>
          <div className="rounded-3xl p-12 md:p-20 text-center relative overflow-hidden" style={{ background: "linear-gradient(135deg, #5baab8 0%, #3d8fa0 50%, #0d1f26 100%)" }}>
            <motion.div
              className="absolute inset-0 opacity-10"
              style={{ backgroundImage: "radial-gradient(circle at 20% 80%, white 0%, transparent 50%), radial-gradient(circle at 80% 20%, white 0%, transparent 50%)" }}
              animate={{ opacity: [0.08, 0.15, 0.08] }}
              transition={{ duration: 8, repeat: Infinity }}
            />
            <div className="relative">
              <h2 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight mb-4 leading-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                Start downloading for free.
                <br />
                Upgrade when you&#39;re ready.
              </h2>
              <p className="text-white/70 text-lg mb-10 max-w-xl mx-auto" style={{ fontFamily: "'Inter', sans-serif" }}>
                No credit card. No account. Just paste a URL and go.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} className="bg-white text-[#0d1f26] font-bold px-8 py-4 rounded-full hover:bg-[#eef6f8] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                  Download Your First Video
                </motion.button>
                <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} className="bg-white/10 hover:bg-white/20 text-white font-semibold px-8 py-4 rounded-full border border-white/30 transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                  See all features
                </motion.button>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  type FooterLink = { label: string; href: string };
  const links: Record<string, FooterLink[]> = {
    Product: [
      { label: "Features", href: "#" },
      { label: "Pricing", href: "/pricing" },
      { label: "API Docs", href: "/api" },
      { label: "Changelog", href: "#" },
      { label: "Status", href: "#" },
    ],
    Platforms: [
      { label: "YouTube", href: "#" },
      { label: "Facebook", href: "#" },
      { label: "TikTok", href: "#" },
      { label: "Instagram", href: "#" },
      { label: "All Platforms", href: "#" },
    ],
    Company: [
      { label: "About", href: "#" },
      { label: "Blog", href: "#" },
      { label: "Careers", href: "#" },
      { label: "Press Kit", href: "#" },
      { label: "Contact", href: "#" },
    ],
    Legal: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "API Disclaimer", href: "/api-disclaimer" },
      { label: "Terms of Service", href: "#" },
      { label: "Cookie Policy", href: "#" },
      { label: "DMCA", href: "#" },
    ],
  };
  const socials = [Youtube, Twitter, Instagram, Facebook, Linkedin];

  return (
    <footer className="bg-[#0d1f26] text-white py-16 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10 mb-12">
          <div className="col-span-2 md:col-span-1 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#5baab8]/20 flex items-center justify-center">
                <Download className="w-4 h-4 text-[#5baab8]" />
              </div>
              <span className="font-bold text-lg" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                fetchwave
              </span>
            </div>
            <p className="text-xs text-white/50 leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}>
              The fastest way to download video, audio, and thumbnails from any platform.
            </p>
            <div className="flex gap-2 mt-1">
              {socials.map((Icon, i) => (
                <motion.a
                  key={i}
                  href="#"
                  whileHover={{ y: -3, scale: 1.1 }}
                  className="w-8 h-8 rounded-lg bg-white/5 hover:bg-[#5baab8]/20 flex items-center justify-center transition-colors"
                >
                  <Icon className="w-4 h-4 text-white/60 hover:text-[#5baab8]" />
                </motion.a>
              ))}
            </div>
          </div>

          {Object.entries(links).map(([section, items]) => (
            <div key={section}>
              <p className="text-xs font-bold tracking-widest uppercase text-white/40 mb-4" style={{ fontFamily: "'DM Mono', monospace" }}>
                {section}
              </p>
              <ul className="flex flex-col gap-2.5">
                {items.map(({ label, href }) => (
                  <li key={label}>
                    {href.startsWith("/") ? (
                      <Link to={href} className="text-sm text-white/60 hover:text-white transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                        {label}
                      </Link>
                    ) : (
                      <a href={href} className="text-sm text-white/60 hover:text-white transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                        {label}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/40" style={{ fontFamily: "'Inter', sans-serif" }}>
            © 2025 fetchwave. All rights reserved.
          </p>
          <div className="flex gap-4 text-xs text-white/30" style={{ fontFamily: "'Inter', sans-serif" }}>
            <Link to="/privacy" className="hover:text-white/60 transition-colors">Privacy</Link>
            <Link to="/api-disclaimer" className="hover:text-white/60 transition-colors">API Disclaimer</Link>
          </div>
          <p className="text-xs text-white/30" style={{ fontFamily: "'DM Mono', monospace" }}>
            v2.4.1 · 99.9% uptime · 500K+ users
          </p>
        </div>
      </div>
    </footer>
  );
}

// ─── App ─────────────────────────────────────────────────────────────────────

export function HomePage() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Nav menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <main>
        <Hero />
        <PlatformGrid />
        <HowItWorks />
        <FormatShowcase />
        <Features />
        <Testimonials />
        <Pricing />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}


function AuthMark() {
  return (
    <Link to="/" className="inline-flex items-center gap-2.5" aria-label="Back to fetchwave home">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#0d1f26] shadow-[0_8px_18px_rgba(13,31,38,0.14)]">
        <Download className="h-4.5 w-4.5 text-[#82c4ce]" />
      </span>
      <span className="font-bold text-xl tracking-[-0.035em] text-[#0d1f26]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>fetchwave</span>
    </Link>
  );
}

function AuthAside() {
  return (
    <aside className="relative hidden min-h-screen overflow-hidden bg-[#0d1f26] p-10 lg:flex lg:w-[46%] lg:flex-col xl:p-14">
      <div className="absolute -left-28 top-20 h-72 w-72 rounded-full bg-[#5baab8]/20 blur-3xl" />
      <div className="absolute -bottom-28 -right-20 h-96 w-96 rounded-full bg-[#2e7586]/30 blur-3xl" />
      <div className="relative flex items-center gap-2.5 text-white">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/10"><Download className="h-4.5 w-4.5 text-[#82c4ce]" /></span>
        <span className="font-bold text-xl tracking-[-0.035em]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>fetchwave</span>
      </div>
      <div className="relative my-auto max-w-md pt-12">
        <p className="mb-5 font-mono text-[11px] font-medium uppercase tracking-[0.2em] text-[#82c4ce]">The faster way to save</p>
        <h2 className="text-[clamp(2.4rem,4vw,4.25rem)] font-semibold leading-[1.06] tracking-[-0.045em] text-white" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
          Keep every great moment within reach.
        </h2>
        <p className="mt-6 max-w-sm text-[15px] leading-7 text-white/65" style={{ fontFamily: "'Inter', sans-serif" }}>
          A calm, capable workspace for video, audio, and thumbnail downloads from the platforms you use every day.
        </p>
      </div>
      <div className="relative rounded-2xl border border-white/10 bg-white/[0.06] p-5 backdrop-blur-sm">
        <div className="mb-4 flex items-center gap-1.5 text-[#f4c46c]">{Array.from({ length: 5 }).map((_, index) => <Star key={index} className="h-3.5 w-3.5 fill-current" />)}</div>
        <p className="text-sm leading-6 text-white/80" style={{ fontFamily: "'Inter', sans-serif" }}>“It is the kind of tool that disappears into your workflow — incredibly fast and genuinely simple.”</p>
        <div className="mt-4 flex items-center gap-3"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#82c4ce] text-xs font-bold text-[#0d1f26]">AL</span><span className="text-xs font-medium text-white/55">Ava Lin · Creator</span></div>
      </div>
    </aside>
  );
}

function SocialButton({ children, icon: Icon }: { children: React.ReactNode; icon: typeof Github }) {
  return <button type="button" className="flex h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-[#cce1e5] bg-white text-sm font-semibold text-[#26414a] transition hover:border-[#82bdc6] hover:bg-[#f8fcfc]" style={{ fontFamily: "'Inter', sans-serif" }}><Icon className="h-4 w-4" />{children}</button>;
}

function AuthPage({ mode }: { mode: "signin" | "signup" }) {
  const isSignUp = mode === "signup";
  const [showPassword, setShowPassword] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [remember, setRemember] = useState(true);
  const [terms, setTerms] = useState(false);
  const submit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); setSubmitted(true); };
  const title = isSignUp ? "Make downloads feel effortless." : "Welcome back to your wave.";

  return (
    <div className="min-h-screen bg-[#f7fbfc] lg:flex">
      <AuthAside />
      <main className="relative flex min-h-screen flex-1 items-center justify-center overflow-hidden px-6 py-10 sm:px-10">
        <div className="pointer-events-none absolute -right-24 top-16 h-64 w-64 rounded-full bg-[#b5e0e6]/35 blur-3xl lg:hidden" />
        <div className="relative w-full max-w-[420px]">
          <div className="mb-11 flex items-center justify-between lg:hidden"><AuthMark /><Link to="/" className="text-xs font-semibold text-[#54737b] hover:text-[#0d1f26]">Back home</Link></div>
          <Link to="/" className="mb-11 hidden items-center gap-2 text-xs font-semibold text-[#54737b] hover:text-[#0d1f26] lg:inline-flex"><ArrowLeft className="h-3.5 w-3.5" /> Back to homepage</Link>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }}>
            <div className="mb-8">
              <p className="mb-3 font-mono text-[10px] font-medium uppercase tracking-[0.19em] text-[#5baab8]">{isSignUp ? "Your free workspace" : "Secure access"}</p>
              <h1 className="max-w-sm text-[32px] font-semibold leading-[1.14] tracking-[-0.04em] text-[#0d1f26] sm:text-[38px]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{title}</h1>
              <p className="mt-3 text-sm leading-6 text-[#63828a]" style={{ fontFamily: "'Inter', sans-serif" }}>{isSignUp ? "Create an account to keep your downloads and preferences in one place." : "Sign in to pick up exactly where you left off."}</p>
            </div>
            <div className="flex gap-3"><SocialButton icon={Github}>GitHub</SocialButton><SocialButton icon={Mail}>Google</SocialButton></div>
            <div className="my-7 flex items-center gap-4"><span className="h-px flex-1 bg-[#d7e7ea]" /><span className="font-mono text-[10px] uppercase tracking-[0.14em] text-[#89a1a7]">or continue with email</span><span className="h-px flex-1 bg-[#d7e7ea]" /></div>
            <form onSubmit={submit} className="space-y-4">
              {isSignUp && <label className="block"><span className="mb-1.5 block text-xs font-semibold text-[#29464e]">Full name</span><input required placeholder="Avery Hart" className="h-12 w-full rounded-xl border border-[#cce1e5] bg-white px-4 text-sm text-[#0d1f26] outline-none placeholder:text-[#9bb1b6] focus:border-[#5baab8] focus:ring-4 focus:ring-[#5baab8]/10" /></label>}
              <label className="block"><span className="mb-1.5 block text-xs font-semibold text-[#29464e]">Email address</span><div className="relative"><Mail className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8da6ac]" /><input required type="email" placeholder="you@example.com" className="h-12 w-full rounded-xl border border-[#cce1e5] bg-white pl-11 pr-4 text-sm text-[#0d1f26] outline-none placeholder:text-[#9bb1b6] focus:border-[#5baab8] focus:ring-4 focus:ring-[#5baab8]/10" /></div></label>
              <label className="block"><span className="mb-1.5 block text-xs font-semibold text-[#29464e]">Password</span><div className="relative"><LockKeyhole className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8da6ac]" /><input required minLength={8} type={showPassword ? "text" : "password"} placeholder={isSignUp ? "At least 8 characters" : "Enter your password"} className="h-12 w-full rounded-xl border border-[#cce1e5] bg-white pl-11 pr-12 text-sm text-[#0d1f26] outline-none placeholder:text-[#9bb1b6] focus:border-[#5baab8] focus:ring-4 focus:ring-[#5baab8]/10" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-[#739198] hover:text-[#0d1f26]" aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></div></label>
              <div className="flex items-start justify-between gap-4 pt-0.5">{isSignUp ? <label className="flex cursor-pointer items-start gap-2.5 text-xs leading-5 text-[#63828a]"><input checked={terms} onChange={(event) => setTerms(event.target.checked)} type="checkbox" className="mt-0.5 h-3.5 w-3.5 accent-[#0d1f26]" />I agree to the <a href="#" className="text-[#2f7e8d] hover:underline">Terms</a> and <a href="#" className="text-[#2f7e8d] hover:underline">Privacy Policy</a>.</label> : <><label className="flex cursor-pointer items-center gap-2 text-xs text-[#63828a]"><input checked={remember} onChange={(event) => setRemember(event.target.checked)} type="checkbox" className="h-3.5 w-3.5 accent-[#0d1f26]" />Remember me</label><a href="#" className="text-xs font-semibold text-[#2f7e8d] hover:underline">Forgot password?</a></>}</div>
              <motion.button whileTap={{ scale: 0.98 }} type="submit" disabled={isSignUp && !terms} className="mt-2 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#0d1f26] text-sm font-semibold text-white shadow-[0_12px_24px_rgba(13,31,38,0.16)] transition hover:bg-[#193743] disabled:cursor-not-allowed disabled:opacity-50">{submitted ? <><Check className="h-4 w-4 text-[#82c4ce]" />{isSignUp ? "Account created" : "Signed in"}</> : isSignUp ? "Create free account" : "Sign in"}</motion.button>
            </form>
            <p className="mt-7 text-center text-sm text-[#63828a]">{isSignUp ? "Already have an account?" : "New to fetchwave?"} <Link to={isSignUp ? "/sign-in" : "/sign-up"} className="font-semibold text-[#28798a] hover:underline">{isSignUp ? "Sign in" : "Create one free"}</Link></p>
            <div className="mt-9 flex items-center justify-center gap-2 text-[11px] text-[#78959b]"><ShieldCheck className="h-3.5 w-3.5 text-[#5baab8]" />Secure, private, and always in your control.</div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

export function SignInPage() { return <AuthPage mode="signin" />; }
export function SignUpPage() { return <AuthPage mode="signup" />; }


// ─── Shared legal layout helpers ─────────────────────────────────────────────

function LegalNav() {
  return (
    <motion.header
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-border"
    >
      <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-7 h-7 rounded-lg bg-[#0d1f26] flex items-center justify-center group-hover:scale-105 transition-transform">
            <Download className="w-3.5 h-3.5 text-[#5baab8]" />
          </div>
          <span className="font-bold text-base tracking-tight text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>fetchwave</span>
        </Link>
        <Link to="/" className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
          <ArrowLeft className="w-3.5 h-3.5" /> Back to home
        </Link>
      </div>
    </motion.header>
  );
}

function LegalHero({ label, title, subtitle, updated }: { label: string; title: string; subtitle: string; updated: string }) {
  return (
    <div className="relative overflow-hidden bg-[#0d1f26] py-20 px-6">
      <motion.div
        className="absolute -top-24 -right-24 w-96 h-96 rounded-full opacity-20 pointer-events-none"
        style={{ background: "radial-gradient(circle, #5baab8 0%, transparent 70%)" }}
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ duration: 10, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-0 left-0 w-64 h-64 rounded-full opacity-10 pointer-events-none"
        style={{ background: "radial-gradient(circle, #a8d4dc 0%, transparent 70%)" }}
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 14, repeat: Infinity }}
      />
      <div className="max-w-4xl mx-auto relative">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <span className="inline-flex items-center gap-2 text-[10px] font-bold tracking-widest uppercase text-[#5baab8] bg-[#5baab8]/10 border border-[#5baab8]/20 px-3 py-1.5 rounded-full mb-6" style={{ fontFamily: "'DM Mono', monospace" }}>
            {label}
          </span>
        </motion.div>
        <motion.h1
          className="text-4xl md:text-6xl font-extrabold text-white tracking-tight leading-[1.06] mb-4"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}
        >
          {title}
        </motion.h1>
        <motion.p className="text-white/60 text-lg max-w-xl leading-relaxed mb-6" style={{ fontFamily: "'Inter', sans-serif" }} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          {subtitle}
        </motion.p>
        <motion.p className="text-xs text-white/30 font-mono" style={{ fontFamily: "'DM Mono', monospace" }} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
          Last updated: {updated}
        </motion.p>
      </div>
    </div>
  );
}

type TocItem = { id: string; label: string };

function TocSidebar({ items, active }: { items: TocItem[]; active: string }) {
  return (
    <nav className="hidden lg:block sticky top-20 w-56 flex-shrink-0 self-start">
      <p className="text-[10px] font-bold tracking-widest uppercase text-muted-foreground mb-4" style={{ fontFamily: "'DM Mono', monospace" }}>Contents</p>
      <ul className="flex flex-col gap-1">
        {items.map((item) => (
          <li key={item.id}>
            <a
              href={`#${item.id}`}
              className={`block text-sm py-1.5 px-3 rounded-lg transition-all border-l-2 ${
                active === item.id
                  ? "border-[#5baab8] text-[#0d1f26] font-semibold bg-[#d4ecf0]/50"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
              }`}
              style={{ fontFamily: "'Inter', sans-serif" }}
            >
              {item.label}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}

function LegalSection({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <motion.section
      id={id}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.5, ease: [0.21, 0.6, 0.35, 1] }}
      className="scroll-mt-24 mb-12"
    >
      <h2 className="text-xl font-bold text-foreground mb-4 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
        <span className="w-1 h-6 rounded-full bg-[#5baab8] flex-shrink-0" />
        {title}
      </h2>
      <div className="prose-content text-sm text-muted-foreground leading-7 space-y-3" style={{ fontFamily: "'Inter', sans-serif" }}>
        {children}
      </div>
    </motion.section>
  );
}

function InfoBox({ variant, children }: { variant: "warning" | "info" | "danger"; children: React.ReactNode }) {
  const styles = {
    warning: "bg-amber-50 border-amber-200 text-amber-900",
    info: "bg-[#eef6f8] border-[#a8d4dc] text-[#0d1f26]",
    danger: "bg-red-50 border-red-200 text-red-900",
  };
  const icons = { warning: "⚠️", info: "ℹ️", danger: "🚫" };
  return (
    <div className={`flex gap-3 rounded-xl border p-4 text-sm leading-6 ${styles[variant]}`} style={{ fontFamily: "'Inter', sans-serif" }}>
      <span className="text-base flex-shrink-0 mt-0.5">{icons[variant]}</span>
      <div>{children}</div>
    </div>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-2.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#5baab8] flex-shrink-0 mt-2" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

function LegalFooter() {
  return (
    <footer className="bg-[#0d1f26] text-white py-10 px-6 mt-16">
      <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#5baab8]/20 flex items-center justify-center">
            <Download className="w-3.5 h-3.5 text-[#5baab8]" />
          </div>
          <span className="font-bold text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>fetchwave</span>
        </div>
        <div className="flex flex-wrap justify-center gap-5 text-xs text-white/50" style={{ fontFamily: "'Inter', sans-serif" }}>
          <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
          <Link to="/api-disclaimer" className="hover:text-white transition-colors">API Disclaimer</Link>
          <Link to="/" className="hover:text-white transition-colors">Home</Link>
        </div>
        <p className="text-xs text-white/30" style={{ fontFamily: "'DM Mono', monospace" }}>© 2025 fetchwave</p>
      </div>
    </footer>
  );
}

// ─── API Disclaimer Page ──────────────────────────────────────────────────────

const apiTocItems: TocItem[] = [
  { id: "overview", label: "Overview" },
  { id: "permitted", label: "Permitted Use" },
  { id: "prohibited", label: "Prohibited Use" },
  { id: "rate-limits", label: "Rate Limits" },
  { id: "authentication", label: "Authentication" },
  { id: "data-handling", label: "Data Handling" },
  { id: "copyright", label: "Copyright & DMCA" },
  { id: "liability", label: "Liability" },
  { id: "versioning", label: "API Versioning" },
  { id: "contact", label: "Contact" },
];

export function ApiDisclaimerPage() {
  const [active] = useState("overview");
  return (
    <div className="min-h-screen bg-background">
      <LegalNav />
      <LegalHero
        label="Developer API"
        title="API Disclaimer"
        subtitle="Guidelines, constraints, and legal boundaries for integrating the fetchwave API into your applications."
        updated="January 15, 2025"
      />

      <div className="max-w-5xl mx-auto px-6 py-16 flex gap-16">
        <TocSidebar items={apiTocItems} active={active} />

        <div className="flex-1 min-w-0">
          {/* Top warning */}
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-12">
            <InfoBox variant="warning">
              <strong>Important:</strong> The fetchwave API is provided for lawful, personal, and authorized commercial use only. Misuse — including circumventing platform protections or downloading copyrighted content without permission — may result in immediate API key revocation and legal action.
            </InfoBox>
          </motion.div>

          <LegalSection id="overview" title="Overview">
            <p>The fetchwave API ("API") allows developers to programmatically access fetchwave's media retrieval and format-conversion capabilities. By using the API you agree to be bound by these terms, our <Link to="/privacy" className="text-[#2f7e8d] hover:underline font-medium">Privacy Policy</Link>, and all applicable local, national, and international laws.</p>
            <p>This disclaimer supplements — and does not replace — the fetchwave Terms of Service. In the event of any conflict, the Terms of Service govern.</p>
            <div className="grid sm:grid-cols-3 gap-4 mt-4">
              {[
                { icon: Zap, label: "REST API", desc: "JSON over HTTPS, fully documented at api.fetchwave.io/docs" },
                { icon: Shield, label: "API Keys", desc: "Per-account keys with granular permission scopes" },
                { icon: Globe, label: "Global CDN", desc: "Response times under 200 ms from 18 edge locations" },
              ].map(({ icon: Icon, label, desc }) => (
                <div key={label} className="bg-white border border-border rounded-xl p-4 flex flex-col gap-2">
                  <Icon className="w-4 h-4 text-[#5baab8]" />
                  <p className="font-semibold text-foreground text-xs" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{label}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>
          </LegalSection>

          <LegalSection id="permitted" title="Permitted Use">
            <p>You may use the API for the following purposes, provided all use complies with the applicable platform's Terms of Service and copyright law:</p>
            <BulletList items={[
              "Personal archival of content you own or have explicit permission to download.",
              "Educational and research projects with no commercial redistribution of downloaded content.",
              "Internal business tooling where your organization holds a valid licence for the content.",
              "Accessibility applications that convert video to audio for users with visual impairments.",
              "Format-conversion pipelines where the source content is your own original work.",
              "Testing and development against our sandbox environment using provided test URLs.",
            ]} />
            <InfoBox variant="info">
              Bulk or automated downloads from a platform must comply with that platform's robots.txt and Terms of Service. fetchwave does not grant rights that the originating platform has not already granted you.
            </InfoBox>
          </LegalSection>

          <LegalSection id="prohibited" title="Prohibited Use">
            <p>The following activities are strictly forbidden and will result in immediate key suspension and potential legal referral:</p>
            <BulletList items={[
              "Downloading, redistributing, or reselling copyrighted content without the rights-holder's explicit permission.",
              "Building services that allow end-users to download platform-restricted content in violation of that platform's ToS.",
              "Circumventing DRM, geo-restrictions, or authentication systems of any third-party platform.",
              "Scraping or bulk-downloading content at a scale that disrupts the originating platform's infrastructure.",
              "Using the API to harvest personal data, metadata, or analytics about individuals without consent.",
              "Reselling or sub-licensing API access to third parties without a written enterprise agreement.",
              "Automated credential stuffing, spam generation, or any form of platform abuse.",
            ]} />
            <InfoBox variant="danger">
              Violations are reported to relevant authorities and originating platforms. We cooperate fully with DMCA takedown notices and law-enforcement requests.
            </InfoBox>
          </LegalSection>

          <LegalSection id="rate-limits" title="Rate Limits & Quotas">
            <p>Rate limits protect platform stability and ensure fair access. Limits reset on a rolling 60-second window:</p>
            <div className="bg-white border border-border rounded-xl overflow-hidden mt-3">
              <table className="w-full text-xs" style={{ fontFamily: "'DM Mono', monospace" }}>
                <thead className="bg-[#eef6f8]">
                  <tr>
                    {["Plan", "Requests / min", "Daily quota", "Concurrent jobs"].map(h => (
                      <th key={h} className="text-left px-4 py-3 font-semibold text-foreground">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {[
                    ["Free", "10", "100", "1"],
                    ["Pro", "60", "Unlimited", "5"],
                    ["Team", "300", "Unlimited", "20"],
                    ["Enterprise", "Custom", "Custom", "Custom"],
                  ].map(([plan, rpm, daily, conc]) => (
                    <tr key={plan} className="hover:bg-[#eef6f8] transition-colors">
                      <td className="px-4 py-3 font-bold text-[#0d1f26]">{plan}</td>
                      <td className="px-4 py-3 text-muted-foreground">{rpm}</td>
                      <td className="px-4 py-3 text-muted-foreground">{daily}</td>
                      <td className="px-4 py-3 text-muted-foreground">{conc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-3">Exceeding rate limits returns HTTP 429. Persistent abuse results in key revocation without refund.</p>
          </LegalSection>

          <LegalSection id="authentication" title="Authentication">
            <p>All API requests must include a valid API key transmitted via the <code className="bg-muted px-1.5 py-0.5 rounded text-xs font-mono text-[#0d1f26]">Authorization: Bearer &lt;key&gt;</code> header. API keys:</p>
            <BulletList items={[
              "Are scoped to a single fetchwave account and non-transferable.",
              "Should be treated as secrets — never commit keys to public repositories.",
              "Can be rotated at any time from your account dashboard without service interruption.",
              "Expire automatically after 12 months of inactivity on Free plans.",
              "Support IP allowlists on Pro and Team plans for additional security.",
            ]} />
            <InfoBox variant="info">
              If you suspect your key has been compromised, revoke it immediately in your dashboard and generate a new one. Notify <span className="font-semibold">security@fetchwave.io</span> if you believe unauthorized usage has occurred.
            </InfoBox>
          </LegalSection>

          <LegalSection id="data-handling" title="Data Handling">
            <p>fetchwave processes URLs and media ephemerally. We do not retain downloaded files beyond the delivery window. Specifically:</p>
            <BulletList items={[
              "Submitted URLs are retained for up to 24 hours solely for deduplication and caching.",
              "Converted media files are held on CDN edge nodes for a maximum of 1 hour after delivery.",
              "API request logs (IP, key hash, endpoint, timestamp) are retained for 30 days for abuse detection.",
              "No personally identifiable information is embedded in or extracted from downloaded content.",
              "Team-plan customers may configure custom retention windows from 0 to 30 days.",
            ]} />
          </LegalSection>

          <LegalSection id="copyright" title="Copyright & DMCA">
            <p>fetchwave respects intellectual property rights and complies fully with the Digital Millennium Copyright Act (DMCA) and equivalent legislation in other jurisdictions. We operate as a neutral technical conduit and do not host or cache copyrighted content beyond the delivery window described above.</p>
            <p>To submit a DMCA takedown notice, email <span className="font-semibold text-[#0d1f26]">dmca@fetchwave.io</span> with:</p>
            <BulletList items={[
              "Your full name, address, telephone number, and email address.",
              "A description of the copyrighted work you claim has been infringed.",
              "The URL or other location of the infringing material.",
              "A statement that you have a good-faith belief that the use is not authorised.",
              "A statement that the information is accurate and, under penalty of perjury, that you are the rights-holder or authorised to act on their behalf.",
              "Your physical or electronic signature.",
            ]} />
          </LegalSection>

          <LegalSection id="liability" title="Liability">
            <p>To the maximum extent permitted by applicable law:</p>
            <BulletList items={[
              "fetchwave provides the API on an 'as is' and 'as available' basis without warranty of any kind.",
              "fetchwave is not liable for indirect, incidental, special, consequential, or punitive damages arising from your use of the API.",
              "Our total aggregate liability for any claims related to the API shall not exceed the fees paid by you in the 12 months preceding the claim.",
              "You are solely responsible for ensuring your use of the API complies with all applicable laws and third-party terms.",
              "fetchwave reserves the right to modify or discontinue the API at any time with 30 days' notice (except in cases of security risk or legal obligation).",
            ]} />
          </LegalSection>

          <LegalSection id="versioning" title="API Versioning">
            <p>fetchwave uses date-based API versioning. The current stable version is <code className="bg-muted px-1.5 py-0.5 rounded text-xs font-mono text-[#0d1f26]">2025-01-15</code>. Each version is supported for a minimum of 12 months after a successor version is released.</p>
            <BulletList items={[
              "Breaking changes are always introduced in new major versions, never patched into existing ones.",
              "Deprecation notices are published at least 6 months before end-of-life.",
              "Non-breaking additions (new fields, new endpoints) may be added at any time to the current version.",
              "Changelog entries are published at api.fetchwave.io/changelog and via webhook (Pro+ plans).",
            ]} />
          </LegalSection>

          <LegalSection id="contact" title="Contact">
            <p>For API-related enquiries:</p>
            <div className="grid sm:grid-cols-2 gap-3 mt-3">
              {[
                { label: "Developer Support", value: "api@fetchwave.io", note: "Response within 24 h (business days)" },
                { label: "Security & Abuse", value: "security@fetchwave.io", note: "Response within 4 h, 24/7" },
                { label: "DMCA & Legal", value: "dmca@fetchwave.io", note: "Responses per statutory deadlines" },
                { label: "Enterprise Sales", value: "enterprise@fetchwave.io", note: "Custom plans and SLA negotiation" },
              ].map(({ label, value, note }) => (
                <div key={label} className="bg-white border border-border rounded-xl p-4">
                  <p className="font-semibold text-foreground text-xs mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{label}</p>
                  <p className="text-[#2f7e8d] font-mono text-xs mb-1">{value}</p>
                  <p className="text-xs text-muted-foreground">{note}</p>
                </div>
              ))}
            </div>
          </LegalSection>
        </div>
      </div>

      <LegalFooter />
    </div>
  );
}

// ─── Privacy Policy Page ──────────────────────────────────────────────────────

const privacyTocItems: TocItem[] = [
  { id: "who-we-are", label: "Who We Are" },
  { id: "info-collected", label: "Information We Collect" },
  { id: "how-we-use", label: "How We Use It" },
  { id: "legal-basis", label: "Legal Basis (GDPR)" },
  { id: "retention", label: "Data Retention" },
  { id: "third-parties", label: "Third Parties" },
  { id: "cookies", label: "Cookies" },
  { id: "your-rights", label: "Your Rights" },
  { id: "security", label: "Security" },
  { id: "children", label: "Children's Privacy" },
  { id: "changes", label: "Policy Changes" },
  { id: "contact-privacy", label: "Contact" },
];

export function PrivacyPolicyPage() {
  const [active] = useState("who-we-are");
  return (
    <div className="min-h-screen bg-background">
      <LegalNav />
      <LegalHero
        label="Legal"
        title="Privacy Policy"
        subtitle="We built fetchwave to be private by design. This policy explains exactly what we collect, why, and how you stay in control."
        updated="January 15, 2025"
      />

      {/* Effective date banner */}
      <div className="bg-[#d4ecf0] border-b border-[#a8d4dc] px-6 py-3">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-[#0d1f26] font-medium" style={{ fontFamily: "'Inter', sans-serif" }}>
            <span className="font-bold">Effective date:</span> January 15, 2025 · Applies to fetchwave.io and all subdomains
          </p>
          <div className="flex gap-4 text-xs" style={{ fontFamily: "'DM Mono', monospace" }}>
            <a href="#your-rights" className="text-[#2f7e8d] hover:underline font-semibold">Your rights →</a>
            <a href="#contact-privacy" className="text-[#2f7e8d] hover:underline font-semibold">Contact DPO →</a>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-16 flex gap-16">
        <TocSidebar items={privacyTocItems} active={active} />

        <div className="flex-1 min-w-0">
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="mb-12">
            <InfoBox variant="info">
              <strong>TL;DR:</strong> We collect only what's necessary to run the service. We don't sell your data. We don't store downloaded files. You can request deletion of your account and all associated data at any time.
            </InfoBox>
          </motion.div>

          <LegalSection id="who-we-are" title="Who We Are">
            <p>fetchwave ("we", "us", "our") is operated by fetchwave Ltd., a company registered in Ireland (EU). Our registered address is 12 Grand Canal Square, Dublin 2, D02 A342, Ireland.</p>
            <p>As a company operating within the European Union, we are subject to the General Data Protection Regulation (GDPR). Our Data Protection Officer can be reached at <span className="font-semibold text-[#0d1f26]">dpo@fetchwave.io</span>.</p>
            <div className="bg-white border border-border rounded-xl p-5 mt-3 flex gap-4 items-start">
              <Shield className="w-5 h-5 text-[#5baab8] flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-foreground text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Privacy-first design</p>
                <p className="text-xs text-muted-foreground leading-relaxed">fetchwave was architected from day one to minimise data collection. Downloaded files are never stored on our servers beyond the delivery window. Your URL history is never sold or shared with advertisers.</p>
              </div>
            </div>
          </LegalSection>

          <LegalSection id="info-collected" title="Information We Collect">
            <p>We collect information in three ways: information you give us, information collected automatically, and information from third parties.</p>
            <p className="font-semibold text-foreground mt-3 mb-1.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Information you give us</p>
            <BulletList items={[
              "Account registration: email address, display name, and hashed password.",
              "Payment information: billing address and last 4 digits of card (full card details are handled by Stripe — we never see them).",
              "Support correspondence: messages you send to our support team.",
              "Feedback and survey responses, if you choose to provide them.",
            ]} />
            <p className="font-semibold text-foreground mt-4 mb-1.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Information collected automatically</p>
            <BulletList items={[
              "URLs submitted to the downloader, retained for up to 24 hours for deduplication and caching.",
              "Server access logs: IP address (anonymised after 24 h), user agent, HTTP method, endpoint, response code, and timestamp.",
              "Performance telemetry: page load times, API response times, and error rates (no user-identifiable data).",
              "Cookie data as described in the Cookies section below.",
            ]} />
            <p className="font-semibold text-foreground mt-4 mb-1.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Information from third parties</p>
            <BulletList items={[
              "If you sign in via GitHub or Google OAuth, we receive your email and public profile name — nothing else.",
              "Stripe provides us with transaction confirmation and limited fraud-prevention signals.",
            ]} />
          </LegalSection>

          <LegalSection id="how-we-use" title="How We Use Your Information">
            <p>We use the information we collect to:</p>
            <BulletList items={[
              "Provide, maintain, and improve the fetchwave service.",
              "Authenticate you and secure your account.",
              "Process payments and issue receipts.",
              "Send transactional emails (download complete, invoice, security alerts) — never marketing without explicit opt-in.",
              "Detect and prevent abuse, fraud, and violations of our Terms of Service.",
              "Comply with legal obligations, including responding to valid law-enforcement requests.",
              "Generate aggregated, anonymised analytics to understand product usage trends.",
            ]} />
            <p className="mt-3">We do <strong className="text-foreground">not</strong> use your data to build advertising profiles, sell to data brokers, or train AI/ML models without explicit consent.</p>
          </LegalSection>

          <LegalSection id="legal-basis" title="Legal Basis (GDPR)">
            <p>For users in the European Economic Area, United Kingdom, and Switzerland, our legal basis for processing is:</p>
            <div className="bg-white border border-border rounded-xl overflow-hidden mt-3">
              <table className="w-full text-xs" style={{ fontFamily: "'Inter', sans-serif" }}>
                <thead className="bg-[#eef6f8]">
                  <tr>
                    {["Processing activity", "Legal basis"].map(h => (
                      <th key={h} className="text-left px-4 py-3 font-semibold text-foreground">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {[
                    ["Account creation and management", "Contract (Art. 6(1)(b))"],
                    ["Payment processing", "Contract (Art. 6(1)(b))"],
                    ["Security logging and abuse prevention", "Legitimate interests (Art. 6(1)(f))"],
                    ["Marketing emails (opt-in)", "Consent (Art. 6(1)(a))"],
                    ["Legal compliance and law-enforcement requests", "Legal obligation (Art. 6(1)(c))"],
                    ["Anonymised analytics", "Legitimate interests (Art. 6(1)(f))"],
                  ].map(([activity, basis]) => (
                    <tr key={activity} className="hover:bg-[#eef6f8] transition-colors">
                      <td className="px-4 py-3 text-muted-foreground">{activity}</td>
                      <td className="px-4 py-3 font-medium text-[#0d1f26]">{basis}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </LegalSection>

          <LegalSection id="retention" title="Data Retention">
            <p>We retain your data for as long as necessary to provide the service and comply with our legal obligations:</p>
            <BulletList items={[
              "Submitted URLs: up to 24 hours for caching and deduplication, then permanently deleted.",
              "Converted media files: up to 1 hour on CDN edge nodes after delivery, then automatically purged.",
              "Account data: for the lifetime of your account, plus 30 days after deletion to allow for accidental re-activation.",
              "Payment records: 7 years as required by EU VAT law.",
              "Server access logs: 30 days before automatic deletion (IP is anonymised after 24 hours).",
              "Support tickets: 2 years after ticket closure.",
            ]} />
            <p className="mt-3">You can request deletion of your account and all associated data at any time from your account settings. Deletion is completed within 30 days.</p>
          </LegalSection>

          <LegalSection id="third-parties" title="Third Parties">
            <p>We share your data with the following categories of third-party processors under strict data processing agreements:</p>
            <div className="grid sm:grid-cols-2 gap-3 mt-3">
              {[
                { name: "Stripe", role: "Payment processing", location: "US/EU", data: "Billing details, transaction history" },
                { name: "Cloudflare", role: "CDN and DDoS protection", location: "Global", data: "Anonymised traffic data" },
                { name: "AWS", role: "Cloud infrastructure", location: "EU (Ireland)", data: "Account data, logs" },
                { name: "PostHog", role: "Product analytics (self-hosted)", location: "EU", data: "Anonymised usage events" },
              ].map(({ name, role, location, data }) => (
                <div key={name} className="bg-white border border-border rounded-xl p-4">
                  <p className="font-bold text-foreground text-sm mb-0.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{name}</p>
                  <p className="text-xs text-[#5baab8] font-medium mb-2">{role} · {location}</p>
                  <p className="text-xs text-muted-foreground">{data}</p>
                </div>
              ))}
            </div>
            <p className="mt-4">We do not sell, rent, or trade your personal data with any third party for their own marketing purposes.</p>
          </LegalSection>

          <LegalSection id="cookies" title="Cookies">
            <p>We use a minimal set of cookies. No third-party advertising cookies are set.</p>
            <div className="bg-white border border-border rounded-xl overflow-hidden mt-3">
              <table className="w-full text-xs" style={{ fontFamily: "'Inter', sans-serif" }}>
                <thead className="bg-[#eef6f8]">
                  <tr>
                    {["Name", "Purpose", "Duration", "Type"].map(h => (
                      <th key={h} className="text-left px-4 py-3 font-semibold text-foreground">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {[
                    ["fw_session", "Authenticated session token", "24 h", "Strictly necessary"],
                    ["fw_csrf", "Cross-site request forgery protection", "Session", "Strictly necessary"],
                    ["fw_prefs", "UI preferences (theme, language)", "1 year", "Functional"],
                    ["_ph_id", "Anonymised analytics (PostHog)", "1 year", "Analytics"],
                  ].map(([name, purpose, duration, type]) => (
                    <tr key={name} className="hover:bg-[#eef6f8] transition-colors">
                      <td className="px-4 py-3 font-mono font-bold text-[#0d1f26]">{name}</td>
                      <td className="px-4 py-3 text-muted-foreground">{purpose}</td>
                      <td className="px-4 py-3 text-muted-foreground">{duration}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${type === "Strictly necessary" ? "bg-[#eef6f8] text-[#3d8fa0]" : type === "Functional" ? "bg-amber-50 text-amber-700" : "bg-purple-50 text-purple-700"}`}>{type}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-3">You can manage cookie preferences via our cookie banner or your browser settings. Blocking strictly necessary cookies may prevent the service from functioning correctly.</p>
          </LegalSection>

          <LegalSection id="your-rights" title="Your Rights">
            <p>Depending on your location, you have some or all of the following rights regarding your personal data:</p>
            <div className="grid sm:grid-cols-2 gap-3 mt-3">
              {[
                { right: "Right of access", desc: "Request a copy of all personal data we hold about you." },
                { right: "Right to rectification", desc: "Correct inaccurate or incomplete data." },
                { right: "Right to erasure", desc: "Request deletion of your data ('right to be forgotten')." },
                { right: "Right to portability", desc: "Receive your data in a machine-readable format." },
                { right: "Right to restrict processing", desc: "Pause processing of your data in certain circumstances." },
                { right: "Right to object", desc: "Object to processing based on legitimate interests." },
                { right: "Right to withdraw consent", desc: "Withdraw consent for processing you previously agreed to." },
                { right: "Right to lodge a complaint", desc: "File a complaint with your national data protection authority." },
              ].map(({ right, desc }) => (
                <div key={right} className="flex gap-3 bg-white border border-border rounded-xl p-4">
                  <CheckCircle2 className="w-4 h-4 text-[#5baab8] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground text-xs mb-0.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{right}</p>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-4">To exercise any of these rights, email <span className="font-semibold text-[#0d1f26]">privacy@fetchwave.io</span> or use the self-service tools in your account settings. We respond within 30 days (GDPR) or 45 days (CCPA).</p>
          </LegalSection>

          <LegalSection id="security" title="Security">
            <p>We implement industry-standard security measures including:</p>
            <BulletList items={[
              "TLS 1.3 encryption for all data in transit.",
              "AES-256 encryption for sensitive data at rest.",
              "Bcrypt password hashing with a minimum cost factor of 12.",
              "Multi-factor authentication (TOTP and WebAuthn) for all accounts.",
              "Regular third-party penetration testing (annual minimum).",
              "SOC 2 Type II compliance (report available on request for Enterprise customers).",
              "A public responsible-disclosure programme at fetchwave.io/security.",
            ]} />
            <InfoBox variant="info">
              If you discover a security vulnerability, please email <strong>security@fetchwave.io</strong>. We aim to respond within 4 hours and will credit researchers in our Hall of Fame.
            </InfoBox>
          </LegalSection>

          <LegalSection id="children" title="Children's Privacy">
            <p>fetchwave is not directed at children under the age of 16 (or such higher age as may apply in your jurisdiction). We do not knowingly collect personal data from children. If you believe a child has provided us with their personal data, contact us at <span className="font-semibold text-[#0d1f26]">privacy@fetchwave.io</span> and we will delete the data promptly.</p>
          </LegalSection>

          <LegalSection id="changes" title="Policy Changes">
            <p>We may update this Privacy Policy from time to time. When we make material changes, we will:</p>
            <BulletList items={[
              "Update the 'Last updated' date at the top of this page.",
              "Send an email notification to all registered users at least 14 days before the change takes effect.",
              "Display a prominent notice on the fetchwave dashboard.",
              "Maintain a version history at fetchwave.io/privacy/history.",
            ]} />
            <p className="mt-3">Continued use of the service after the effective date constitutes acceptance of the revised policy.</p>
          </LegalSection>

          <LegalSection id="contact-privacy" title="Contact">
            <p>For privacy-related enquiries or to exercise your rights:</p>
            <div className="grid sm:grid-cols-2 gap-3 mt-3">
              {[
                { label: "Data Protection Officer", value: "dpo@fetchwave.io", note: "GDPR requests and regulatory enquiries" },
                { label: "Privacy Team", value: "privacy@fetchwave.io", note: "General privacy questions and rights requests" },
                { label: "Postal address", value: "fetchwave Ltd., 12 Grand Canal Square, Dublin 2, D02 A342, Ireland", note: "For formal legal correspondence" },
                { label: "Supervisory Authority", value: "Data Protection Commission (Ireland)", note: "dataprotection.ie · +353 57 868 4800" },
              ].map(({ label, value, note }) => (
                <div key={label} className="bg-white border border-border rounded-xl p-4">
                  <p className="font-semibold text-foreground text-xs mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{label}</p>
                  <p className="text-[#2f7e8d] font-mono text-xs mb-1 break-words">{value}</p>
                  <p className="text-xs text-muted-foreground">{note}</p>
                </div>
              ))}
            </div>
          </LegalSection>
        </div>
      </div>

      <LegalFooter />
    </div>
  );
}

// ─── Shared page nav (for standalone pages) ───────────────────────────────────

function PageNav() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.55, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-xl border-b border-border"
    >
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <motion.div whileHover={{ scale: 1.03 }}>
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#0d1f26] flex items-center justify-center">
              <Download className="w-4 h-4 text-[#5baab8]" />
            </div>
            <span className="font-bold text-lg tracking-tight text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              fetchwave
            </span>
          </Link>
        </motion.div>
        <nav className="hidden md:flex items-center gap-8">
          {[["Features", "/"], ["Platforms", "/"], ["Pricing", "/pricing"], ["API", "/api"]].map(([label, href]) => (
            <Link key={label} to={href} className="relative text-sm font-medium text-muted-foreground hover:text-foreground transition-colors group" style={{ fontFamily: "'Inter', sans-serif" }}>
              {label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#5baab8] group-hover:w-full transition-all duration-300" />
            </Link>
          ))}
        </nav>
        <div className="hidden md:flex items-center gap-3">
          <Link to="/sign-in" className="text-sm font-medium text-foreground hover:text-accent transition-colors px-4 py-2" style={{ fontFamily: "'Inter', sans-serif" }}>Sign in</Link>
          <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}>
            <Link to="/sign-up" className="text-sm font-semibold bg-[#0d1f26] text-white px-5 py-2.5 rounded-full hover:bg-[#1a3545] transition-colors block" style={{ fontFamily: "'Inter', sans-serif" }}>
              Start Free
            </Link>
          </motion.div>
        </div>
        <button className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>
      <AnimatePresence>
        {menuOpen && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="md:hidden bg-white border-t border-border overflow-hidden">
            <div className="px-6 py-4 flex flex-col gap-4">
              {[["Features", "/"], ["Platforms", "/"], ["Pricing", "/pricing"], ["API", "/api"]].map(([label, href]) => (
                <Link key={label} to={href} className="text-sm font-medium text-foreground py-1">{label}</Link>
              ))}
              <Link to="/sign-up" className="text-sm font-semibold bg-[#0d1f26] text-white px-5 py-3 rounded-full text-center">Start Free</Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}

// ─── API Page ─────────────────────────────────────────────────────────────────

const CODE_EXAMPLES: Record<string, string> = {
  curl: `curl -X POST https://api.fetchwave.io/v1/download \\
  -H "Authorization: Bearer fw_live_••••••••" \\
  -H "Content-Type: application/json" \\
  -d '{
    "url": "https://youtube.com/watch?v=dQw4w9WgXcQ",
    "format": "mp4",
    "quality": "1080p"
  }'`,
  javascript: `import Fetchwave from "@fetchwave/sdk";

const client = new Fetchwave({
  apiKey: process.env.FETCHWAVE_API_KEY,
});

const job = await client.download.create({
  url: "https://youtube.com/watch?v=dQw4w9WgXcQ",
  format: "mp4",
  quality: "1080p",
});

console.log(job.downloadUrl); // CDN URL, valid 1 h`,
  python: `from fetchwave import Fetchwave

client = Fetchwave(api_key="fw_live_••••••••")

job = client.download.create(
    url="https://youtube.com/watch?v=dQw4w9WgXcQ",
    format="mp4",
    quality="1080p",
)

print(job.download_url)  # CDN URL, valid 1 h`,
};

const RESPONSE_JSON = `{
  "id": "job_01HXYZ3K8M2N9P",
  "status": "completed",
  "format": "mp4",
  "quality": "1080p",
  "size_bytes": 284901234,
  "duration_ms": 213000,
  "download_url": "https://cdn.fetchwave.io/dl/…",
  "expires_at": "2025-01-15T14:30:00Z",
  "platform": "youtube",
  "title": "Never Gonna Give You Up"
}`;

const ENDPOINTS = [
  { method: "POST", path: "/v1/download", desc: "Create a download job", auth: true, tier: "Free" },
  { method: "GET", path: "/v1/download/:id", desc: "Poll job status", auth: true, tier: "Free" },
  { method: "GET", path: "/v1/formats", desc: "List available formats for a URL", auth: true, tier: "Free" },
  { method: "POST", path: "/v1/batch", desc: "Submit up to 50 URLs in one call", auth: true, tier: "Pro" },
  { method: "GET", path: "/v1/batch/:id", desc: "Poll batch job status", auth: true, tier: "Pro" },
  { method: "POST", path: "/v1/playlist", desc: "Download an entire playlist", auth: true, tier: "Pro" },
  { method: "GET", path: "/v1/usage", desc: "Fetch your quota & usage stats", auth: true, tier: "Free" },
  { method: "GET", path: "/v1/platforms", desc: "List all 200+ supported platforms", auth: false, tier: "Free" },
  { method: "DELETE", path: "/v1/download/:id", desc: "Cancel a pending job", auth: true, tier: "Free" },
  { method: "POST", path: "/v1/webhooks", desc: "Register a webhook endpoint", auth: true, tier: "Pro" },
];

const METHOD_COLORS: Record<string, string> = {
  GET: "bg-emerald-50 text-emerald-700 border-emerald-200",
  POST: "bg-blue-50 text-blue-700 border-blue-200",
  DELETE: "bg-red-50 text-red-700 border-red-200",
};

const apiNavItems = [
  { id: "quickstart", label: "Quick Start" },
  { id: "authentication", label: "Authentication" },
  { id: "endpoints", label: "Endpoints" },
  { id: "response", label: "Response Schema" },
  { id: "errors", label: "Error Codes" },
  { id: "sdks", label: "SDKs & Libraries" },
  { id: "webhooks", label: "Webhooks" },
  { id: "rate-limits", label: "Rate Limits" },
  { id: "changelog", label: "Changelog" },
];

function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false);
  function copy() {
    navigator.clipboard.writeText(code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }
  return (
    <div className="relative rounded-xl overflow-hidden border border-[#1e3545] bg-[#0a1720]">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#1e3545]">
        <span className="text-[10px] font-bold tracking-widest uppercase text-[#5baab8]/70" style={{ fontFamily: "'DM Mono', monospace" }}>{lang}</span>
        <button onClick={copy} className="flex items-center gap-1.5 text-[10px] text-white/40 hover:text-white transition-colors">
          <AnimatePresence mode="wait">
            {copied ? (
              <motion.span key="done" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-1 text-[#5baab8]">
                <CheckCircle2 className="w-3 h-3" /> Copied
              </motion.span>
            ) : (
              <motion.span key="copy" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-1">
                <Copy className="w-3 h-3" /> Copy
              </motion.span>
            )}
          </AnimatePresence>
        </button>
      </div>
      <pre className="p-4 text-xs leading-6 text-[#a8d4dc] overflow-x-auto" style={{ fontFamily: "'DM Mono', monospace" }}>
        <code>{code}</code>
      </pre>
    </div>
  );
}

export function ApiPage() {
  const [activeLang, setActiveLang] = useState<"curl" | "javascript" | "python">("curl");
  const langs = ["curl", "javascript", "python"] as const;

  return (
    <div className="min-h-screen bg-background">
      <PageNav />

      {/* Hero */}
      <div className="relative overflow-hidden bg-[#0d1f26] pt-32 pb-20 px-6">
        <motion.div className="absolute -top-32 -right-32 w-[500px] h-[500px] rounded-full opacity-20 pointer-events-none"
          style={{ background: "radial-gradient(circle, #5baab8 0%, transparent 70%)" }}
          animate={{ scale: [1, 1.15, 1] }} transition={{ duration: 12, repeat: Infinity }} />
        <motion.div className="absolute bottom-0 left-10 w-64 h-64 rounded-full opacity-10 pointer-events-none"
          style={{ background: "radial-gradient(circle, #a8d4dc 0%, transparent 70%)" }}
          animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 16, repeat: Infinity }} />
        <div className="max-w-5xl mx-auto relative">
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <span className="inline-flex items-center gap-2 text-[10px] font-bold tracking-widest uppercase text-[#5baab8] bg-[#5baab8]/10 border border-[#5baab8]/20 px-3 py-1.5 rounded-full mb-6" style={{ fontFamily: "'DM Mono', monospace" }}>
              <span className="w-1.5 h-1.5 rounded-full bg-[#5baab8] animate-pulse" /> REST API · v2025-01-15
            </span>
          </motion.div>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <motion.h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight leading-[1.06] mb-5"
                style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                Build with the fetchwave API.
              </motion.h1>
              <motion.p className="text-white/60 text-lg leading-relaxed mb-8" style={{ fontFamily: "'Inter', sans-serif" }}
                initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
                Programmatic access to 200+ platform downloads, format conversion, and batch processing — all behind a single clean REST interface.
              </motion.p>
              <motion.div className="flex flex-wrap gap-3" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.26 }}>
                <Link to="/sign-up" className="inline-flex items-center gap-2 bg-[#5baab8] hover:bg-[#3d8fa0] text-white font-semibold text-sm px-6 py-3 rounded-full transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                  Get API Key <ArrowRight className="w-4 h-4" />
                </Link>
                <a href="#endpoints" className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/15 text-white font-semibold text-sm px-6 py-3 rounded-full border border-white/20 transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                  Browse Endpoints
                </a>
              </motion.div>
            </div>
            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.22, duration: 0.6 }}>
              <CodeBlock code={CODE_EXAMPLES.curl} lang="Quick Start · cURL" />
            </motion.div>
          </div>
          {/* Stats strip */}
          <motion.div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4"
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
            {[
              { value: "< 200ms", label: "Median response" },
              { value: "99.98%", label: "Uptime SLA" },
              { value: "200+", label: "Platforms" },
              { value: "18", label: "Edge locations" },
            ].map(({ value, label }) => (
              <div key={label} className="bg-white/5 border border-white/10 rounded-xl px-5 py-4">
                <p className="text-2xl font-extrabold text-white mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{value}</p>
                <p className="text-xs text-white/50" style={{ fontFamily: "'Inter', sans-serif" }}>{label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Main content */}
      <div className="max-w-5xl mx-auto px-6 py-16 flex gap-14">
        {/* Sidebar TOC */}
        <nav className="hidden lg:block sticky top-20 w-52 flex-shrink-0 self-start">
          <p className="text-[10px] font-bold tracking-widest uppercase text-muted-foreground mb-4" style={{ fontFamily: "'DM Mono', monospace" }}>Reference</p>
          <ul className="flex flex-col gap-0.5">
            {apiNavItems.map((item) => (
              <li key={item.id}>
                <a href={`#${item.id}`} className="block text-sm py-1.5 px-3 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-all border-l-2 border-transparent hover:border-[#5baab8]" style={{ fontFamily: "'Inter', sans-serif" }}>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-8 p-4 bg-[#0d1f26] rounded-xl">
            <p className="text-xs font-bold text-white mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Need help?</p>
            <p className="text-xs text-white/50 mb-3" style={{ fontFamily: "'Inter', sans-serif" }}>Our dev team responds in under 24 h.</p>
            <a href="mailto:api@fetchwave.io" className="text-xs font-semibold text-[#5baab8] hover:text-[#a8d4dc] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
              api@fetchwave.io →
            </a>
          </div>
        </nav>

        {/* Content */}
        <div className="flex-1 min-w-0 space-y-14">

          {/* Quick Start */}
          <motion.section id="quickstart" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Quick Start
            </h2>
            <p className="text-sm text-muted-foreground mb-6 leading-7" style={{ fontFamily: "'Inter', sans-serif" }}>Get your first download in under 2 minutes. Pick a language:</p>
            <div className="flex gap-2 mb-4">
              {langs.map((lang) => (
                <button key={lang} onClick={() => setActiveLang(lang)}
                  className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all border ${activeLang === lang ? "bg-[#0d1f26] text-white border-[#0d1f26]" : "bg-white text-muted-foreground border-border hover:border-[#5baab8]"}`}
                  style={{ fontFamily: "'DM Mono', monospace" }}>
                  {lang}
                </button>
              ))}
            </div>
            <AnimatePresence mode="wait">
              <motion.div key={activeLang} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }}>
                <CodeBlock code={CODE_EXAMPLES[activeLang]} lang={activeLang} />
              </motion.div>
            </AnimatePresence>
            <div className="mt-4 grid sm:grid-cols-3 gap-3">
              {[
                { step: "1", title: "Get your API key", desc: "Sign up free and find your key in dashboard → Settings → API." },
                { step: "2", title: "Make a request", desc: "POST the video URL with your desired format and quality." },
                { step: "3", title: "Download the file", desc: "Receive a CDN URL valid for 1 hour. Stream or save directly." },
              ].map(({ step, title, desc }) => (
                <div key={step} className="bg-white border border-border rounded-xl p-4">
                  <span className="text-3xl font-extrabold text-[#eef6f8] select-none" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{step}</span>
                  <p className="font-bold text-foreground text-sm mt-1 mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}>{desc}</p>
                </div>
              ))}
            </div>
          </motion.section>

          {/* Authentication */}
          <motion.section id="authentication" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Authentication
            </h2>
            <p className="text-sm text-muted-foreground mb-5 leading-7" style={{ fontFamily: "'Inter', sans-serif" }}>
              All API requests require a Bearer token in the <code className="bg-muted px-1.5 py-0.5 rounded text-xs font-mono text-[#0d1f26]">Authorization</code> header.
            </p>
            <CodeBlock code={`Authorization: Bearer fw_live_sk_a1b2c3d4e5f6g7h8i9j0`} lang="Header" />
            <div className="mt-5 grid sm:grid-cols-2 gap-3">
              {[
                { icon: Shield, title: "Key scopes", desc: "Create read-only or full-access keys. Narrow scope = smaller blast radius." },
                { icon: Clock, title: "Key rotation", desc: "Rotate keys from the dashboard at any time with zero downtime." },
                { icon: Globe, title: "IP allowlisting", desc: "Restrict keys to specific CIDR ranges (Pro+)." },
                { icon: Zap, title: "Zero config", desc: "No OAuth flows or token refresh — a single static key is all you need." },
              ].map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex gap-3 bg-white border border-border rounded-xl p-4">
                  <Icon className="w-4 h-4 text-[#5baab8] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground text-xs mb-0.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{title}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}>{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.section>

          {/* Endpoints */}
          <motion.section id="endpoints" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Endpoints
            </h2>
            <p className="text-sm text-muted-foreground mb-5 leading-7" style={{ fontFamily: "'Inter', sans-serif" }}>
              Base URL: <code className="bg-muted px-1.5 py-0.5 rounded text-xs font-mono text-[#0d1f26]">https://api.fetchwave.io</code>
            </p>
            <div className="bg-white border border-border rounded-2xl overflow-hidden">
              <div className="grid grid-cols-[80px_1fr_1fr_60px] text-[10px] font-bold tracking-widest uppercase text-muted-foreground px-5 py-3 bg-[#eef6f8] border-b border-border" style={{ fontFamily: "'DM Mono', monospace" }}>
                <span>Method</span><span>Path</span><span>Description</span><span>Tier</span>
              </div>
              {ENDPOINTS.map((ep, i) => (
                <motion.div key={i}
                  className="grid grid-cols-[80px_1fr_1fr_60px] items-center px-5 py-3.5 border-b border-border last:border-0 hover:bg-[#f7fbfc] transition-colors group"
                  initial={{ opacity: 0, x: -12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}>
                  <span className={`inline-flex w-14 items-center justify-center rounded-md border px-2 py-0.5 text-[10px] font-bold ${METHOD_COLORS[ep.method]}`} style={{ fontFamily: "'DM Mono', monospace" }}>{ep.method}</span>
                  <code className="text-xs text-[#0d1f26] font-mono">{ep.path}</code>
                  <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{ep.desc}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full text-center ${ep.tier === "Pro" ? "bg-[#d4ecf0] text-[#3d8fa0]" : "bg-muted text-muted-foreground"}`} style={{ fontFamily: "'DM Mono', monospace" }}>{ep.tier}</span>
                </motion.div>
              ))}
            </div>
          </motion.section>

          {/* Response Schema */}
          <motion.section id="response" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Response Schema
            </h2>
            <p className="text-sm text-muted-foreground mb-5 leading-7" style={{ fontFamily: "'Inter', sans-serif" }}>
              All responses are <code className="bg-muted px-1.5 py-0.5 rounded text-xs font-mono text-[#0d1f26]">application/json</code>. Successful job responses follow this shape:
            </p>
            <CodeBlock code={RESPONSE_JSON} lang="JSON Response" />
            <div className="mt-4 bg-white border border-border rounded-2xl overflow-hidden">
              {[
                { field: "id", type: "string", desc: "Unique job identifier (ULID format)" },
                { field: "status", type: '"pending" | "processing" | "completed" | "failed"', desc: "Current job state" },
                { field: "format", type: "string", desc: "Output format: mp4, mp3, flac, webp, …" },
                { field: "quality", type: "string", desc: "Video resolution or audio bitrate" },
                { field: "size_bytes", type: "number", desc: "Output file size in bytes" },
                { field: "duration_ms", type: "number", desc: "Media duration in milliseconds" },
                { field: "download_url", type: "string", desc: "Signed CDN URL. Valid for 1 hour after job completion." },
                { field: "expires_at", type: "ISO 8601", desc: "Timestamp when the download_url expires" },
              ].map(({ field, type, desc }) => (
                <div key={field} className="grid grid-cols-[130px_160px_1fr] items-start px-5 py-3 border-b border-border last:border-0 hover:bg-[#f7fbfc] transition-colors text-xs">
                  <code className="font-mono font-bold text-[#0d1f26]">{field}</code>
                  <code className="font-mono text-[#5baab8]">{type}</code>
                  <span className="text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{desc}</span>
                </div>
              ))}
            </div>
          </motion.section>

          {/* Error Codes */}
          <motion.section id="errors" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Error Codes
            </h2>
            <p className="text-sm text-muted-foreground mb-5 leading-7" style={{ fontFamily: "'Inter', sans-serif" }}>
              Errors follow <code className="bg-muted px-1.5 py-0.5 rounded text-xs font-mono text-[#0d1f26]">{"{ code, message, docs_url }"}</code>. HTTP status codes:
            </p>
            <div className="bg-white border border-border rounded-2xl overflow-hidden">
              {[
                { code: "400", label: "Bad Request", desc: "Missing or invalid parameters — check the request body." },
                { code: "401", label: "Unauthorized", desc: "API key missing, expired, or revoked." },
                { code: "403", label: "Forbidden", desc: "Valid key but insufficient scope for this endpoint." },
                { code: "404", label: "Not Found", desc: "Job ID does not exist or has been purged." },
                { code: "422", label: "Unprocessable", desc: "URL is valid but the platform or content is unsupported." },
                { code: "429", label: "Rate Limited", desc: "Exceeded your plan's request quota. See Retry-After header." },
                { code: "500", label: "Server Error", desc: "Something went wrong on our end. Retryable with exponential backoff." },
                { code: "503", label: "Unavailable", desc: "Source platform is temporarily unreachable." },
              ].map(({ code, label, desc }) => (
                <div key={code} className="flex items-start gap-4 px-5 py-3.5 border-b border-border last:border-0 hover:bg-[#f7fbfc] transition-colors">
                  <span className={`text-xs font-bold px-2 py-1 rounded-lg min-w-[42px] text-center ${code.startsWith("4") || code.startsWith("5") ? "bg-red-50 text-red-600 border border-red-200" : "bg-emerald-50 text-emerald-600 border border-emerald-200"}`} style={{ fontFamily: "'DM Mono', monospace" }}>{code}</span>
                  <div>
                    <p className="text-xs font-semibold text-foreground mb-0.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{label}</p>
                    <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.section>

          {/* SDKs */}
          <motion.section id="sdks" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> SDKs & Libraries
            </h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { lang: "JavaScript / TypeScript", install: "npm install @fetchwave/sdk", badge: "Official", version: "v3.2.1" },
                { lang: "Python", install: "pip install fetchwave", badge: "Official", version: "v2.1.0" },
                { lang: "PHP", install: "composer require fetchwave/fetchwave", badge: "Official", version: "v1.8.3" },
                { lang: "Ruby", install: "gem install fetchwave", badge: "Community", version: "v1.2.0" },
                { lang: "Go", install: "go get github.com/fetchwave/go-sdk", badge: "Community", version: "v0.9.1" },
                { lang: "Rust", install: "cargo add fetchwave", badge: "Community", version: "v0.4.0" },
              ].map(({ lang, install, badge, version }) => (
                <div key={lang} className="bg-white border border-border rounded-xl p-4 group hover:border-[#5baab8] transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <p className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{lang}</p>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${badge === "Official" ? "bg-[#d4ecf0] text-[#3d8fa0]" : "bg-muted text-muted-foreground"}`} style={{ fontFamily: "'DM Mono', monospace" }}>{badge}</span>
                      <span className="text-[10px] text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{version}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between bg-[#eef6f8] rounded-lg px-3 py-2">
                    <code className="text-xs text-[#0d1f26]" style={{ fontFamily: "'DM Mono', monospace" }}>{install}</code>
                    <Copy className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer" />
                  </div>
                </div>
              ))}
            </div>
          </motion.section>

          {/* Webhooks */}
          <motion.section id="webhooks" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Webhooks
            </h2>
            <p className="text-sm text-muted-foreground mb-5 leading-7" style={{ fontFamily: "'Inter', sans-serif" }}>
              Register endpoints to receive real-time job updates instead of polling. Available on Pro and Team plans.
            </p>
            <div className="grid sm:grid-cols-2 gap-3 mb-5">
              {["job.completed", "job.failed", "batch.completed", "quota.warning"].map((evt) => (
                <div key={evt} className="bg-white border border-border rounded-xl px-4 py-3 flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full bg-[#5baab8]" />
                  <code className="text-xs font-mono text-[#0d1f26]">{evt}</code>
                </div>
              ))}
            </div>
            <CodeBlock code={`// fetchwave signs every payload with HMAC-SHA256
// Verify before processing:

const sig = req.headers["fw-signature"];
const expected = crypto
  .createHmac("sha256", process.env.WEBHOOK_SECRET)
  .update(rawBody)
  .digest("hex");

if (sig !== \`sha256=\${expected}\`) {
  return res.status(401).send("Invalid signature");
}`} lang="Webhook Verification · JavaScript" />
          </motion.section>

          {/* Rate Limits */}
          <motion.section id="rate-limits" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Rate Limits
            </h2>
            <div className="bg-white border border-border rounded-2xl overflow-hidden mb-4">
              <table className="w-full text-xs" style={{ fontFamily: "'DM Mono', monospace" }}>
                <thead className="bg-[#eef6f8]">
                  <tr>{["Plan", "Req / min", "Daily", "Concurrent", "Batch size"].map(h => <th key={h} className="text-left px-4 py-3 font-semibold text-foreground">{h}</th>)}</tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {[["Free","10","100","1","—"],["Pro","60","Unlimited","5","50"],["Team","300","Unlimited","20","200"],["Enterprise","Custom","Custom","Custom","Custom"]].map(row => (
                    <tr key={row[0]} className="hover:bg-[#f7fbfc] transition-colors">
                      {row.map((cell, i) => <td key={i} className={`px-4 py-3 ${i === 0 ? "font-bold text-[#0d1f26]" : "text-muted-foreground"}`}>{cell}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground leading-6" style={{ fontFamily: "'Inter', sans-serif" }}>
              Rate-limit headers are returned on every response: <code className="bg-muted px-1.5 py-0.5 rounded font-mono text-[#0d1f26]">X-RateLimit-Limit</code>, <code className="bg-muted px-1.5 py-0.5 rounded font-mono text-[#0d1f26]">X-RateLimit-Remaining</code>, <code className="bg-muted px-1.5 py-0.5 rounded font-mono text-[#0d1f26]">Retry-After</code>.
            </p>
          </motion.section>

          {/* Changelog */}
          <motion.section id="changelog" className="scroll-mt-24"
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              <span className="w-1 h-7 rounded-full bg-[#5baab8]" /> Changelog
            </h2>
            <div className="relative pl-6 border-l-2 border-border space-y-8">
              {[
                { date: "Jan 15, 2025", version: "2025-01-15", label: "Current", items: ["Added FLAC and WAV audio output formats.", "Webhook retry logic with exponential backoff (up to 5 attempts).", "New /v1/platforms endpoint listing all 200+ supported sites."] },
                { date: "Oct 3, 2024", version: "2024-10-03", label: null, items: ["Batch endpoint raised from 25 to 50 URLs per call.", "IP allowlisting now available on Pro plan.", "Introduced X-RateLimit-* response headers on all routes."] },
                { date: "Jun 12, 2024", version: "2024-06-12", label: null, items: ["TikTok and Instagram Reels support added.", "Response time improvements — median down from 380 ms to 195 ms.", "WebP thumbnail output added."] },
              ].map(({ date, version, label, items }) => (
                <div key={version} className="relative">
                  <span className="absolute -left-[29px] w-3 h-3 rounded-full bg-[#5baab8] border-2 border-white top-1" />
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs font-bold text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{version}</span>
                    <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{date}</span>
                    {label && <span className="text-[10px] font-bold bg-[#d4ecf0] text-[#3d8fa0] px-2 py-0.5 rounded-full" style={{ fontFamily: "'DM Mono', monospace" }}>{label}</span>}
                  </div>
                  <ul className="space-y-1.5">
                    {items.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>
                        <span className="w-1.5 h-1.5 rounded-full bg-[#5baab8] flex-shrink-0 mt-2" />{item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </motion.section>

        </div>
      </div>

      <LegalFooter />
    </div>
  );
}

// ─── Pricing Page ─────────────────────────────────────────────────────────────

const ALL_FEATURES = [
  { label: "Downloads per day", free: "10", pro: "Unlimited", team: "Unlimited" },
  { label: "Max video quality", free: "1080p", pro: "4K (2160p)", team: "4K (2160p)" },
  { label: "Audio formats", free: "MP3, AAC", pro: "MP3, AAC, FLAC, WAV, OGG", team: "MP3, AAC, FLAC, WAV, OGG" },
  { label: "Thumbnail formats", free: "JPG", pro: "JPG, PNG, WebP", team: "JPG, PNG, WebP" },
  { label: "Supported platforms", free: "50+", pro: "200+", team: "200+" },
  { label: "Batch / playlist download", free: false, pro: true, team: true },
  { label: "Concurrent downloads", free: "1", pro: "5", team: "20" },
  { label: "API access", free: false, pro: "60 req/min", team: "300 req/min" },
  { label: "Webhooks", free: false, pro: true, team: true },
  { label: "Team seats", free: "1", pro: "1", team: "5" },
  { label: "Custom data retention", free: false, pro: false, team: "Up to 30 days" },
  { label: "Priority processing", free: false, pro: true, team: true },
  { label: "No ads", free: false, pro: true, team: true },
  { label: "Email support", free: "Community", pro: "Email (24 h)", team: "Priority (4 h)" },
  { label: "SLA", free: "None", pro: "99.9%", team: "99.99%" },
];

const FAQ = [
  { q: "Is the free plan really free forever?", a: "Yes. The Free plan has no trial period. It stays free for as long as you want, with 10 downloads per day and no credit card required." },
  { q: "Can I switch plans at any time?", a: "Absolutely. Upgrades are instant. Downgrades take effect at the end of your current billing cycle and you keep Pro access until then." },
  { q: "What counts as a 'download'?", a: "Each unique job — video, audio extraction, or thumbnail — counts as one download. Re-downloading the same file from a cached CDN URL does not consume an additional credit." },
  { q: "Do you offer annual billing?", a: "Yes. Annual billing saves 20% vs monthly. You can switch to annual from your account settings at any time." },
  { q: "Is there a student or non-profit discount?", a: "Yes — 50% off Pro for verified students and registered non-profits. Email billing@fetchwave.io with proof of status." },
  { q: "What payment methods do you accept?", a: "Visa, Mastercard, Amex, and PayPal. All payments are processed by Stripe. We never store card details." },
];

function CheckMark({ value }: { value: boolean | string }) {
  if (value === false) return <X className="w-4 h-4 text-muted-foreground/40 mx-auto" />;
  if (value === true) return <CheckCircle2 className="w-4 h-4 text-[#5baab8] mx-auto" />;
  return <span className="text-xs font-medium text-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{value}</span>;
}

export function PricingPage() {
  const [annual, setAnnual] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const pricingPlans = [
    { name: "Free", monthly: "$0", annually: "$0", period: "forever", color: "border-border", highlight: false, badge: null,
      desc: "For casual users and personal archival.",
      features: ["10 downloads / day","1080p max quality","MP3 & MP4","50+ platforms","Community support"],
      cta: "Get Started Free", ctaStyle: "bg-[#0d1f26] text-white hover:bg-[#1a3545]" },
    { name: "Pro", monthly: "$9", annually: "$7", period: "/ month", color: "border-[#0d1f26]", highlight: true, badge: "Most Popular",
      desc: "For creators, researchers, and power users.",
      features: ["Unlimited downloads","4K Ultra HD","All formats incl. FLAC & WebP","200+ platforms","Batch playlist downloads","Priority processing","No ads","API access"],
      cta: "Start 7-day Free Trial", ctaStyle: "bg-[#5baab8] text-white hover:bg-[#3d8fa0]" },
    { name: "Team", monthly: "$29", annually: "$23", period: "/ month", color: "border-border", highlight: false, badge: null,
      desc: "For studios, agencies, and growing teams.",
      features: ["Everything in Pro","5 team seats","300 req/min API","Webhooks & batch 200","Priority support (4 h SLA)","Custom 30-day retention"],
      cta: "Start Team Trial", ctaStyle: "bg-[#0d1f26] text-white hover:bg-[#1a3545]" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <PageNav />

      {/* Hero */}
      <div className="relative overflow-hidden pt-32 pb-20 px-6">
        <motion.div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full opacity-20 pointer-events-none"
          style={{ background: "radial-gradient(ellipse, #5baab8 0%, transparent 70%)" }}
          animate={{ scale: [1, 1.08, 1] }} transition={{ duration: 10, repeat: Infinity }} />
        <div className="max-w-3xl mx-auto text-center relative">
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <span className="inline-flex items-center gap-2 text-[10px] font-bold tracking-widest uppercase text-[#5baab8] bg-[#5baab8]/10 border border-[#5baab8]/20 px-3 py-1.5 rounded-full mb-6" style={{ fontFamily: "'DM Mono', monospace" }}>
              Transparent pricing · No hidden fees
            </span>
          </motion.div>
          <motion.h1 className="text-5xl md:text-7xl font-extrabold text-foreground tracking-tight leading-[1.06] mb-5"
            style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            Start free.<br />Scale when ready.
          </motion.h1>
          <motion.p className="text-lg text-muted-foreground max-w-xl mx-auto mb-10 leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}
            initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
            Every plan includes a 7-day free trial of Pro. No credit card required on Free.
          </motion.p>

          {/* Toggle */}
          <motion.div className="inline-flex items-center gap-4 bg-white border border-border rounded-full px-5 py-3 shadow-sm"
            initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.25 }}>
            <button onClick={() => setAnnual(false)} className={`text-sm font-semibold transition-colors ${!annual ? "text-foreground" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>Monthly</button>
            <button onClick={() => setAnnual(!annual)} className={`relative w-12 h-6 rounded-full transition-colors ${annual ? "bg-[#0d1f26]" : "bg-muted"}`}>
              <motion.span className="absolute top-1 w-4 h-4 rounded-full bg-white shadow"
                animate={{ left: annual ? 26 : 4 }} transition={{ type: "spring", stiffness: 500, damping: 30 }} />
            </button>
            <button onClick={() => setAnnual(true)} className={`text-sm font-semibold transition-colors ${annual ? "text-foreground" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>
              Annual <span className="ml-1.5 text-xs font-bold text-[#5baab8] bg-[#d4ecf0] px-1.5 py-0.5 rounded-full">-20%</span>
            </button>
          </motion.div>
        </div>
      </div>

      {/* Plan cards */}
      <div className="max-w-5xl mx-auto px-6 pb-16">
        <motion.div className="grid md:grid-cols-3 gap-5"
          variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.1 } } }}
          initial="hidden" animate="visible">
          {pricingPlans.map((plan) => (
            <motion.div key={plan.name}
              variants={{ hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } }}
              whileHover={{ y: -8 }}
              className={`relative rounded-2xl border-2 p-7 flex flex-col gap-5 transition-shadow ${plan.highlight ? "bg-[#0d1f26] shadow-2xl" : "bg-white hover:shadow-lg"} ${plan.color}`}>
              {plan.badge && (
                <motion.span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-[10px] font-bold tracking-widest uppercase bg-[#5baab8] text-white px-4 py-1 rounded-full shadow-md"
                  style={{ fontFamily: "'DM Mono', monospace" }}
                  initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.4 }}>
                  {plan.badge}
                </motion.span>
              )}
              <div>
                <p className={`text-xs font-bold tracking-widest uppercase mb-2 ${plan.highlight ? "text-[#5baab8]" : "text-muted-foreground"}`} style={{ fontFamily: "'DM Mono', monospace" }}>{plan.name}</p>
                <div className="flex items-baseline gap-1 mb-1">
                  <AnimatePresence mode="wait">
                    <motion.span key={annual ? "a" : "m"} className={`text-5xl font-extrabold tracking-tight ${plan.highlight ? "text-white" : "text-foreground"}`}
                      style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
                      initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} transition={{ duration: 0.2 }}>
                      {annual ? plan.annually : plan.monthly}
                    </motion.span>
                  </AnimatePresence>
                  <span className={`text-sm ${plan.highlight ? "text-white/50" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>{plan.period}</span>
                </div>
                <p className={`text-xs leading-5 ${plan.highlight ? "text-white/50" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>{plan.desc}</p>
              </div>
              <ul className="flex flex-col gap-2.5 flex-1">
                {plan.features.map((feat) => (
                  <li key={feat} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-[#5baab8] flex-shrink-0 mt-0.5" />
                    <span className={`text-sm leading-tight ${plan.highlight ? "text-white/80" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>{feat}</span>
                  </li>
                ))}
              </ul>
              <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                className={`w-full py-3.5 rounded-xl font-semibold text-sm transition-colors ${plan.ctaStyle}`}
                style={{ fontFamily: "'Inter', sans-serif" }}>
                {plan.cta}
              </motion.button>
            </motion.div>
          ))}
        </motion.div>

        {/* Social proof strip */}
        <motion.div className="mt-10 flex flex-wrap justify-center gap-8 text-center"
          initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
          {[
            { value: "500K+", label: "Active users" },
            { value: "99.9%", label: "Uptime" },
            { value: "< 3s", label: "Avg. processing" },
            { value: "4.9 / 5", label: "User rating" },
          ].map(({ value, label }) => (
            <div key={label}>
              <p className="text-2xl font-extrabold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{value}</p>
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{label}</p>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Feature comparison table */}
      <div className="max-w-5xl mx-auto px-6 pb-20">
        <Reveal>
          <h2 className="text-2xl md:text-3xl font-extrabold text-foreground tracking-tight mb-2 text-center" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Full feature comparison
          </h2>
          <p className="text-center text-sm text-muted-foreground mb-10" style={{ fontFamily: "'Inter', sans-serif" }}>Everything side by side — no fine print.</p>
        </Reveal>
        <Reveal>
          <div className="bg-white border border-border rounded-2xl overflow-hidden">
            <div className="grid grid-cols-[1fr_80px_80px_80px] bg-[#eef6f8] border-b border-border px-5 py-4">
              <span className="text-xs font-bold text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>Feature</span>
              {["Free","Pro","Team"].map((t) => (
                <span key={t} className={`text-xs font-extrabold text-center ${t === "Pro" ? "text-[#5baab8]" : "text-foreground"}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{t}</span>
              ))}
            </div>
            {ALL_FEATURES.map(({ label, free, pro, team }, i) => (
              <motion.div key={label}
                className="grid grid-cols-[1fr_80px_80px_80px] items-center px-5 py-3.5 border-b border-border last:border-0 hover:bg-[#f7fbfc] transition-colors"
                initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.03 }}>
                <span className="text-sm text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{label}</span>
                <div className="text-center"><CheckMark value={free} /></div>
                <div className="text-center"><CheckMark value={pro} /></div>
                <div className="text-center"><CheckMark value={team} /></div>
              </motion.div>
            ))}
          </div>
        </Reveal>
      </div>

      {/* Testimonials row */}
      <div className="bg-[#0d1f26] py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <Reveal>
            <p className="text-center text-[10px] font-bold tracking-widest uppercase text-[#5baab8] mb-8" style={{ fontFamily: "'DM Mono', monospace" }}>
              What people say about Pro
            </p>
          </Reveal>
          <motion.div className="grid md:grid-cols-3 gap-5"
            variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.1 } } }}
            initial="hidden" whileInView="visible" viewport={{ once: true }}>
            {[
              { text: "Upgrading to Pro was the easiest $9 I've ever spent. Batch downloads alone save me 3 hours a week.", name: "Jordan T.", role: "Video Editor" },
              { text: "The API is beautifully designed. I plugged it into our media pipeline in an afternoon.", name: "Priya M.", role: "Backend Engineer" },
              { text: "FLAC extraction at 4K quality is flawless. I use it for every review video I produce.", name: "Sam K.", role: "Tech Reviewer" },
            ].map(({ text, name, role }) => (
              <motion.div key={name} variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
                className="bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col gap-4">
                <div className="flex gap-1">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-[#5baab8] text-[#5baab8]" />)}</div>
                <p className="text-sm text-white/75 leading-relaxed flex-1" style={{ fontFamily: "'Inter', sans-serif" }}>&ldquo;{text}&rdquo;</p>
                <div className="flex items-center gap-3 pt-2 border-t border-white/10">
                  <div className="w-8 h-8 rounded-full bg-[#5baab8]/30 text-[#a8d4dc] text-xs font-bold flex items-center justify-center">
                    {name.split(" ").map(w => w[0]).join("")}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-white" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{name}</p>
                    <p className="text-[10px] text-white/40" style={{ fontFamily: "'Inter', sans-serif" }}>{role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* FAQ */}
      <div className="max-w-2xl mx-auto px-6 py-20">
        <Reveal>
          <h2 className="text-2xl md:text-3xl font-extrabold text-foreground tracking-tight mb-10 text-center" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Frequently asked questions
          </h2>
        </Reveal>
        <div className="space-y-3">
          {FAQ.map(({ q, a }, i) => (
            <motion.div key={i} className="bg-white border border-border rounded-xl overflow-hidden"
              initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}>
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between px-5 py-4 text-left"
              >
                <span className="font-semibold text-sm text-foreground pr-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{q}</span>
                <motion.span animate={{ rotate: openFaq === i ? 45 : 0 }} transition={{ duration: 0.2 }} className="flex-shrink-0">
                  <X className={`w-4 h-4 transition-colors ${openFaq === i ? "text-[#5baab8]" : "text-muted-foreground rotate-45"}`} />
                </motion.span>
              </button>
              <AnimatePresence>
                {openFaq === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.22 }} className="overflow-hidden">
                    <p className="px-5 pb-5 text-sm text-muted-foreground leading-7" style={{ fontFamily: "'Inter', sans-serif" }}>{a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="px-6 pb-20">
        <Reveal>
          <div className="max-w-4xl mx-auto rounded-3xl p-12 md:p-16 text-center relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, #5baab8 0%, #3d8fa0 50%, #0d1f26 100%)" }}>
            <motion.div className="absolute inset-0 opacity-10"
              style={{ backgroundImage: "radial-gradient(circle at 20% 80%, white 0%, transparent 50%), radial-gradient(circle at 80% 20%, white 0%, transparent 50%)" }}
              animate={{ opacity: [0.08, 0.16, 0.08] }} transition={{ duration: 8, repeat: Infinity }} />
            <div className="relative">
              <h2 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight mb-4 leading-tight" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                Start free today.
              </h2>
              <p className="text-white/70 text-lg mb-8 max-w-lg mx-auto" style={{ fontFamily: "'Inter', sans-serif" }}>
                No credit card on Free. 7-day Pro trial on paid plans. Cancel any time.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                  <Link to="/sign-up" className="inline-flex items-center gap-2 bg-white text-[#0d1f26] font-bold px-8 py-4 rounded-full hover:bg-[#eef6f8] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                    Get started free <ArrowRight className="w-4 h-4" />
                  </Link>
                </motion.div>
                <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                  <Link to="/api" className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-8 py-4 rounded-full border border-white/30 transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                    Explore the API
                  </Link>
                </motion.div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      <LegalFooter />
    </div>
  );
}

export default function App() {
  return <RouterProvider router={router} />;
}
