import { createBrowserRouter } from "react-router";

export const router = createBrowserRouter([
  { path: "/", lazy: async () => ({ Component: (await import("./App")).HomePage }) },
  { path: "/sign-in", lazy: async () => ({ Component: (await import("./App")).SignInPage }) },
  { path: "/sign-up", lazy: async () => ({ Component: (await import("./App")).SignUpPage }) },
  { path: "/api-disclaimer", lazy: async () => ({ Component: (await import("./App")).ApiDisclaimerPage }) },
  { path: "/privacy", lazy: async () => ({ Component: (await import("./App")).PrivacyPolicyPage }) },
  { path: "/api", lazy: async () => ({ Component: (await import("./App")).ApiPage }) },
  { path: "/pricing", lazy: async () => ({ Component: (await import("./App")).PricingPage }) },
  { path: "/dashboard", lazy: async () => ({ Component: (await import("./Dashboard")).DashboardPage }) },
  { path: "*", lazy: async () => ({ Component: (await import("./App")).HomePage }) },
]);
