import { useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar,
} from "recharts";
import {
  Download, Zap, Shield, Globe, Key, CreditCard, Settings, BarChart2, Bell,
  LogOut, Copy, CheckCircle2, X, Plus, Eye, EyeOff, Trash2, RefreshCw,
  ArrowUpRight, ArrowDownRight,
  AlertTriangle, Check, User, Lock, ChevronRight, Sparkles, FileText,
  Activity, Star,
} from "lucide-react";

// ─── Inline brand SVGs (dashboard) ───────────────────────────────────────────

type SvgProps = { className?: string; style?: React.CSSProperties };

function YtIcon({ className, style }: SvgProps) {
  return <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor"><path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z" /></svg>;
}
function IgIcon({ className, style }: SvgProps) {
  return <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" /></svg>;
}
function TtIcon({ className, style }: SvgProps) {
  return <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-4.77-4.32V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.18 8.18 0 0 0 4.78 1.52V6.76a4.85 4.85 0 0 1-1.01-.07z" /></svg>;
}
function FbIcon({ className, style }: SvgProps) {
  return <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047v-2.66c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.264h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z" /></svg>;
}
function XIcon({ className, style }: SvgProps) {
  return <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" /></svg>;
}
function VimeoIcon({ className, style }: SvgProps) {
  return <svg viewBox="0 0 24 24" className={className} style={style} fill="currentColor"><path d="M23.977 6.416c-.105 2.338-1.739 5.543-4.894 9.609-3.268 4.247-6.026 6.37-8.29 6.37-1.409 0-2.578-1.294-3.553-3.881L5.322 11.4C4.603 8.816 3.834 7.522 3.01 7.522c-.179 0-.806.378-1.881 1.132L0 7.197c1.185-1.044 2.351-2.084 3.501-3.128C5.08 2.701 6.266 1.984 7.055 1.91c1.867-.18 3.016 1.1 3.447 3.838.465 2.953.789 4.789.971 5.507.539 2.45 1.131 3.674 1.776 3.674.502 0 1.256-.796 2.265-2.385 1.004-1.589 1.54-2.797 1.612-3.628.144-1.371-.395-2.061-1.612-2.061-.574 0-1.167.121-1.777.391 1.186-3.868 3.434-5.757 6.762-5.637 2.473.06 3.628 1.664 3.478 4.807z" /></svg>;
}

const PLATFORM_ICON_MAP: Record<string, { Icon: React.ComponentType<SvgProps>; bg: string; fg: string }> = {
  YouTube:   { Icon: YtIcon,    bg: "#FF0000", fg: "#fff" },
  Instagram: { Icon: IgIcon,    bg: "#E1306C", fg: "#fff" },
  TikTok:    { Icon: TtIcon,    bg: "#010101", fg: "#fff" },
  Facebook:  { Icon: FbIcon,    bg: "#1877F2", fg: "#fff" },
  Twitter:   { Icon: XIcon,     bg: "#14171A", fg: "#fff" },
  Vimeo:     { Icon: VimeoIcon, bg: "#1AB7EA", fg: "#fff" },
};

// ─── Mock data ────────────────────────────────────────────────────────────────

const apiCallsData = [
  { day: "Jan 1", calls: 420, errors: 12 },
  { day: "Jan 3", calls: 680, errors: 8 },
  { day: "Jan 5", calls: 540, errors: 22 },
  { day: "Jan 7", calls: 910, errors: 5 },
  { day: "Jan 9", calls: 1240, errors: 18 },
  { day: "Jan 11", calls: 980, errors: 11 },
  { day: "Jan 13", calls: 1540, errors: 9 },
  { day: "Jan 15", calls: 1820, errors: 14 },
  { day: "Jan 17", calls: 1380, errors: 6 },
  { day: "Jan 19", calls: 2100, errors: 21 },
  { day: "Jan 21", calls: 1750, errors: 8 },
  { day: "Jan 23", calls: 2340, errors: 17 },
  { day: "Jan 25", calls: 2080, errors: 12 },
  { day: "Jan 27", calls: 2650, errors: 9 },
  { day: "Jan 29", calls: 2420, errors: 15 },
];

const downloadsByPlatform = [
  { platform: "YouTube", count: 4812, color: "#FF0000" },
  { platform: "Instagram", count: 2104, color: "#E1306C" },
  { platform: "TikTok", count: 1876, color: "#5baab8" },
  { platform: "Facebook", count: 943, color: "#1877F2" },
  { platform: "Twitter", count: 612, color: "#14171A" },
  { platform: "Vimeo", count: 284, color: "#1AB7EA" },
];

type ApiKey = {
  id: string; name: string; key: string; created: string; lastUsed: string;
  calls: number; scope: string[]; status: "active" | "inactive"; tier: string;
};

const initialApiKeys: ApiKey[] = [
  { id: "k1", name: "Production App", key: "fw_live_sk_a1b2c3d4e5f6g7h8", created: "Jan 2, 2025", lastUsed: "2 min ago", calls: 28450, scope: ["read", "write", "batch"], status: "active", tier: "Pro" },
  { id: "k2", name: "Staging Environment", key: "fw_live_sk_x9y8z7w6v5u4t3s2", created: "Dec 18, 2024", lastUsed: "4 hours ago", calls: 4120, scope: ["read", "write"], status: "active", tier: "Pro" },
  { id: "k3", name: "Analytics Script", key: "fw_live_sk_q1r2s3t4u5v6w7x8", created: "Nov 5, 2024", lastUsed: "3 days ago", calls: 892, scope: ["read"], status: "inactive", tier: "Free" },
];

type DlItem = {
  id: string; url: string; platform: string; format: string;
  quality: string; size: string; status: "completed" | "failed" | "processing";
  time: string; duration: string;
};

const recentDownloads: DlItem[] = [
  { id: "d1", url: "https://youtube.com/watch?v=...", platform: "YouTube",   format: "MP4",  quality: "1080p",   size: "284 MB", status: "completed",  time: "2 min ago",   duration: "3:24" },
  { id: "d2", url: "https://instagram.com/reel/...", platform: "Instagram",  format: "MP4",  quality: "720p",    size: "48 MB",  status: "completed",  time: "18 min ago",  duration: "0:45" },
  { id: "d3", url: "https://tiktok.com/@user/...",   platform: "TikTok",     format: "MP3",  quality: "320kbps", size: "8.2 MB", status: "processing", time: "Just now",    duration: "—"    },
  { id: "d4", url: "https://youtube.com/watch?v=...", platform: "YouTube",   format: "FLAC", quality: "Lossless",size: "92 MB",  status: "completed",  time: "1 hour ago",  duration: "4:12" },
  { id: "d5", url: "https://facebook.com/video/...", platform: "Facebook",   format: "MP4",  quality: "480p",    size: "31 MB",  status: "failed",     time: "2 hours ago", duration: "—"    },
  { id: "d6", url: "https://twitter.com/i/status/...",platform: "Twitter",   format: "MP4",  quality: "720p",    size: "22 MB",  status: "completed",  time: "3 hours ago", duration: "1:08" },
  { id: "d7", url: "https://vimeo.com/...",           platform: "Vimeo",     format: "MP4",  quality: "4K",      size: "1.2 GB", status: "completed",  time: "Yesterday",   duration: "12:40"},
];

type Invoice = {
  id: string; date: string; desc: string; amount: string; status: "paid" | "pending" | "failed";
};

const invoices: Invoice[] = [
  { id: "INV-2025-001", date: "Jan 1, 2025", desc: "Pro Plan — January 2025", amount: "$9.00", status: "paid" },
  { id: "INV-2024-012", date: "Dec 1, 2024", desc: "Pro Plan — December 2024", amount: "$9.00", status: "paid" },
  { id: "INV-2024-011", date: "Nov 1, 2024", desc: "Pro Plan — November 2024", amount: "$9.00", status: "paid" },
  { id: "INV-2024-010", date: "Oct 1, 2024", desc: "Pro Plan — October 2024", amount: "$9.00", status: "paid" },
  { id: "INV-2024-009", date: "Sep 1, 2024", desc: "Pro Plan — September 2024", amount: "$9.00", status: "paid" },
];

// ─── Sidebar ──────────────────────────────────────────────────────────────────

type Tab = "overview" | "api-keys" | "downloads" | "billing" | "settings";

const NAV_ITEMS: { id: Tab; label: string; icon: typeof BarChart2 }[] = [
  { id: "overview", label: "Overview", icon: BarChart2 },
  { id: "api-keys", label: "API Keys", icon: Key },
  { id: "downloads", label: "Downloads", icon: Download },
  { id: "billing", label: "Billing", icon: CreditCard },
  { id: "settings", label: "Settings", icon: Settings },
];

function Sidebar({ active, setActive, collapsed, setCollapsed }: {
  active: Tab; setActive: (t: Tab) => void; collapsed: boolean; setCollapsed: (v: boolean) => void;
}) {
  return (
    <motion.aside
      animate={{ width: collapsed ? 64 : 220 }}
      transition={{ duration: 0.25, ease: "easeInOut" }}
      className="hidden md:flex flex-col bg-[#0d1f26] h-screen sticky top-0 flex-shrink-0 overflow-hidden"
    >
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 h-16 border-b border-white/10 flex-shrink-0">
        <div className="w-8 h-8 rounded-lg bg-[#5baab8]/20 flex items-center justify-center flex-shrink-0">
          <Download className="w-4 h-4 text-[#5baab8]" />
        </div>
        <AnimatePresence>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }}
              className="font-bold text-white text-base tracking-tight whitespace-nowrap"
              style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
            >
              fetchwave
            </motion.span>
          )}
        </AnimatePresence>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="ml-auto text-white/30 hover:text-white transition-colors flex-shrink-0"
        >
          <ChevronRight className={`w-4 h-4 transition-transform ${collapsed ? "" : "rotate-180"}`} />
        </button>
      </div>

      {/* Nav items */}
      <nav className="flex-1 px-2 py-4 space-y-0.5">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActive(id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group relative ${
              active === id ? "bg-white/10 text-white" : "text-white/50 hover:text-white hover:bg-white/5"
            }`}
            style={{ fontFamily: "'Inter', sans-serif" }}
          >
            {active === id && (
              <motion.span layoutId="sidebarActive" className="absolute inset-0 bg-white/10 rounded-xl" transition={{ type: "spring", stiffness: 400, damping: 35 }} />
            )}
            <Icon className="w-4 h-4 relative z-10 flex-shrink-0" />
            <AnimatePresence>
              {!collapsed && (
                <motion.span
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="relative z-10 whitespace-nowrap"
                >
                  {label}
                </motion.span>
              )}
            </AnimatePresence>
            {active === id && !collapsed && (
              <motion.span layoutId="dot" className="ml-auto w-1.5 h-1.5 rounded-full bg-[#5baab8] relative z-10" />
            )}
          </button>
        ))}
      </nav>

      {/* Bottom user */}
      <div className="px-2 pb-4 border-t border-white/10 pt-4">
        <div className={`flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer ${collapsed ? "justify-center" : ""}`}>
          <div className="w-8 h-8 rounded-full bg-[#5baab8]/30 flex items-center justify-center flex-shrink-0">
            <span className="text-xs font-bold text-[#a8d4dc]">AH</span>
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-white truncate" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Avery Hart</p>
                <p className="text-[10px] text-white/40 truncate" style={{ fontFamily: "'Inter', sans-serif" }}>avery@example.com</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <button className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-white/40 hover:text-white hover:bg-white/5 transition-colors mt-1 ${collapsed ? "justify-center" : ""}`}>
          <LogOut className="w-4 h-4 flex-shrink-0" />
          <AnimatePresence>
            {!collapsed && (
              <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-xs" style={{ fontFamily: "'Inter', sans-serif" }}>Sign out</motion.span>
            )}
          </AnimatePresence>
        </button>
      </div>
    </motion.aside>
  );
}

// ─── Topbar ───────────────────────────────────────────────────────────────────

function Topbar({ activeTab }: { activeTab: Tab }) {
  const labels: Record<Tab, string> = {
    overview: "Overview",
    "api-keys": "API Keys",
    downloads: "Downloads",
    billing: "Billing & Payments",
    settings: "Settings",
  };
  return (
    <header className="h-16 bg-white border-b border-border flex items-center justify-between px-6 flex-shrink-0 sticky top-0 z-30">
      <div>
        <h1 className="font-bold text-foreground text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{labels[activeTab]}</h1>
        <p className="text-[10px] text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>fetchwave dashboard · Pro plan</p>
      </div>
      <div className="flex items-center gap-3">
        <button className="relative p-2 rounded-lg hover:bg-muted transition-colors">
          <Bell className="w-4 h-4 text-muted-foreground" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-[#5baab8]" />
        </button>
        <Link to="/" className="flex items-center gap-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors px-3 py-2 rounded-lg hover:bg-muted" style={{ fontFamily: "'Inter', sans-serif" }}>
          <Globe className="w-3.5 h-3.5" /> View site
        </Link>
        <div className="w-8 h-8 rounded-full bg-[#d4ecf0] flex items-center justify-center">
          <span className="text-xs font-bold text-[#0d1f26]">AH</span>
        </div>
      </div>
    </header>
  );
}

// ─── Stat card ────────────────────────────────────────────────────────────────

function StatCard({ label, value, delta, deltaLabel, icon: Icon, accent = false }: {
  label: string; value: string; delta?: number; deltaLabel?: string;
  icon: typeof BarChart2; accent?: boolean;
}) {
  const positive = (delta ?? 0) >= 0;
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className={`rounded-2xl p-5 border flex flex-col gap-3 ${accent ? "bg-[#0d1f26] border-[#0d1f26]" : "bg-white border-border hover:border-[#5baab8] hover:shadow-md"} transition-all`}
    >
      <div className="flex items-center justify-between">
        <span className={`text-xs font-semibold ${accent ? "text-white/50" : "text-muted-foreground"}`} style={{ fontFamily: "'Inter', sans-serif" }}>{label}</span>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${accent ? "bg-white/10" : "bg-[#eef6f8]"}`}>
          <Icon className={`w-4 h-4 ${accent ? "text-[#5baab8]" : "text-[#5baab8]"}`} />
        </div>
      </div>
      <div>
        <p className={`text-3xl font-extrabold tracking-tight ${accent ? "text-white" : "text-foreground"}`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{value}</p>
        {delta !== undefined && (
          <div className={`flex items-center gap-1 mt-1 text-xs font-medium ${positive ? "text-emerald-500" : "text-red-500"}`} style={{ fontFamily: "'Inter', sans-serif" }}>
            {positive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
            {Math.abs(delta)}% {deltaLabel}
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ─── Custom recharts tooltip ──────────────────────────────────────────────────

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number; name: string }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#0d1f26] border border-white/10 rounded-xl px-4 py-3 shadow-xl">
      <p className="text-[10px] text-white/50 mb-2" style={{ fontFamily: "'DM Mono', monospace" }}>{label}</p>
      {payload.map((p) => (
        <p key={p.name} className="text-sm font-semibold text-white" style={{ fontFamily: "'Inter', sans-serif" }}>
          {p.name === "calls" ? "✓ " : "✗ "}{p.value.toLocaleString()} {p.name}
        </p>
      ))}
    </div>
  );
}

// ─── Overview Tab ─────────────────────────────────────────────────────────────

function OverviewTab() {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <motion.div className="grid grid-cols-2 lg:grid-cols-4 gap-4"
        variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.07 } } }}
        initial="hidden" animate="visible">
        {[
          { label: "API Calls (Jan)", value: "28,450", delta: 18, deltaLabel: "vs last month", icon: Activity, accent: true },
          { label: "Success Rate", value: "99.4%", delta: 0.3, deltaLabel: "vs last month", icon: CheckCircle2 },
          { label: "Active API Keys", value: "2", delta: undefined, deltaLabel: undefined, icon: Key },
          { label: "Downloads (Jan)", value: "10,631", delta: 24, deltaLabel: "vs last month", icon: Download },
        ].map((s, i) => (
          <motion.div key={i} variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}>
            <StatCard {...s} />
          </motion.div>
        ))}
      </motion.div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* API calls area chart */}
        <motion.div className="lg:col-span-2 bg-white border border-border rounded-2xl p-6"
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>API Calls</h3>
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>January 2025 — daily volume</p>
            </div>
            <span className="text-[10px] font-bold bg-[#d4ecf0] text-[#3d8fa0] px-3 py-1 rounded-full" style={{ fontFamily: "'DM Mono', monospace" }}>Live</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={apiCallsData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="callsGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#5baab8" stopOpacity={0.18} />
                  <stop offset="95%" stopColor="#5baab8" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="errorsGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.12} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef6f8" />
              <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#5a7d87", fontFamily: "DM Mono" }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#5a7d87", fontFamily: "DM Mono" }} tickLine={false} axisLine={false} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="calls" stroke="#5baab8" strokeWidth={2} fill="url(#callsGrad)" dot={false} activeDot={{ r: 4, fill: "#5baab8" }} />
              <Area type="monotone" dataKey="errors" stroke="#ef4444" strokeWidth={1.5} fill="url(#errorsGrad)" dot={false} activeDot={{ r: 3, fill: "#ef4444" }} />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-3">
            {[{ color: "bg-[#5baab8]", label: "Successful calls" }, { color: "bg-red-400", label: "Errors" }].map(({ color, label }) => (
              <div key={label} className="flex items-center gap-1.5">
                <span className={`w-2.5 h-2.5 rounded-full ${color}`} />
                <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Downloads by platform */}
        <motion.div className="bg-white border border-border rounded-2xl p-6"
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.28 }}>
          <h3 className="font-bold text-foreground text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>By Platform</h3>
          <p className="text-xs text-muted-foreground mb-5" style={{ fontFamily: "'Inter', sans-serif" }}>Downloads this month</p>
          <div className="space-y-3">
            {downloadsByPlatform.map(({ platform, count, color }) => {
              const pct = Math.round((count / downloadsByPlatform[0].count) * 100);
              return (
                <div key={platform}>
                  <div className="flex justify-between mb-1">
                    <span className="text-xs font-medium text-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{platform}</span>
                    <span className="text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{count.toLocaleString()}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <motion.div className="h-full rounded-full" style={{ backgroundColor: color }}
                      initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ delay: 0.3, duration: 0.8, ease: "easeOut" }} />
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>

      {/* Recent downloads table */}
      <motion.div className="bg-white border border-border rounded-2xl overflow-hidden"
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Recent Downloads</h3>
          <button className="text-xs font-semibold text-[#5baab8] hover:text-[#3d8fa0] transition-colors flex items-center gap-1" style={{ fontFamily: "'Inter', sans-serif" }}>
            View all <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="divide-y divide-border">
          {recentDownloads.slice(0, 5).map((dl, i) => {
            const brand = PLATFORM_ICON_MAP[dl.platform] ?? PLATFORM_ICON_MAP["YouTube"];
            const { Icon, bg, fg } = brand;
            return (
              <motion.div key={dl.id}
                className="flex items-center gap-4 px-6 py-3.5 hover:bg-[#f7fbfc] transition-colors"
                initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 + i * 0.05 }}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: bg + "22" }}>
                  <Icon className="w-4 h-4" style={{ color: bg }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground truncate" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{dl.platform} · {dl.format} {dl.quality}</p>
                  <p className="text-[10px] text-muted-foreground truncate" style={{ fontFamily: "'Inter', sans-serif" }}>{dl.url}</p>
                </div>
                <div className="hidden sm:flex items-center gap-4 text-xs text-muted-foreground flex-shrink-0" style={{ fontFamily: "'DM Mono', monospace" }}>
                  <span>{dl.size}</span>
                  <span>{dl.duration}</span>
                  <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                    dl.status === "completed" ? "bg-emerald-50 text-emerald-700" :
                    dl.status === "failed" ? "bg-red-50 text-red-600" :
                    "bg-[#d4ecf0] text-[#3d8fa0]"
                  }`}>{dl.status}</span>
                </div>
                <span className="text-[10px] text-muted-foreground flex-shrink-0" style={{ fontFamily: "'Inter', sans-serif" }}>{dl.time}</span>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* Usage quota */}
      <motion.div className="bg-white border border-border rounded-2xl p-6"
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Usage &amp; Quota</h3>
            <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>Pro plan · Resets Feb 1, 2025</p>
          </div>
          <Link to="/pricing" className="text-xs font-semibold text-[#5baab8] hover:text-[#3d8fa0] transition-colors flex items-center gap-1" style={{ fontFamily: "'Inter', sans-serif" }}>
            Upgrade <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>
        <div className="grid sm:grid-cols-3 gap-5">
          {[
            { label: "API calls", used: 28450, total: "Unlimited", pct: 0 },
            { label: "Storage (temp)", used: 1.2, total: 5, unit: "GB", pct: 24 },
            { label: "Concurrent jobs", used: 2, total: 5, pct: 40 },
          ].map(({ label, used, total, pct, unit }) => (
            <div key={label}>
              <div className="flex justify-between mb-2">
                <span className="text-xs font-medium text-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{label}</span>
                <span className="text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                  {typeof used === "number" && unit ? `${used} ${unit}` : used.toLocaleString()} / {total === "Unlimited" ? "∞" : typeof total === "number" && unit ? `${total} ${unit}` : total}
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                {total === "Unlimited" ? (
                  <motion.div className="h-full bg-gradient-to-r from-[#5baab8] to-[#3d8fa0] rounded-full w-full"
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} />
                ) : (
                  <motion.div className={`h-full rounded-full ${pct > 80 ? "bg-red-400" : pct > 60 ? "bg-amber-400" : "bg-[#5baab8]"}`}
                    initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ delay: 0.5, duration: 0.8 }} />
                )}
              </div>
              {total === "Unlimited" && (
                <p className="text-[10px] text-[#5baab8] mt-1 font-semibold" style={{ fontFamily: "'DM Mono', monospace" }}>UNLIMITED</p>
              )}
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

// ─── API Keys Tab ─────────────────────────────────────────────────────────────

function ApiKeysTab() {
  const [keys, setKeys] = useState<ApiKey[]>(initialApiKeys);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newKeyName, setNewKeyName] = useState("");
  const [newKeyScopes, setNewKeyScopes] = useState(["read"]);
  const [createdKey, setCreatedKey] = useState<string | null>(null);

  function toggleVisible(id: string) {
    setVisibleKeys((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function copyKey(id: string, key: string) {
    navigator.clipboard.writeText(key).catch(() => {});
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  function revokeKey(id: string) {
    setKeys((prev) => prev.map((k) => k.id === id ? { ...k, status: "inactive" as const } : k));
  }

  function createKey() {
    if (!newKeyName.trim()) return;
    const rawKey = `fw_live_sk_${Math.random().toString(36).slice(2, 18)}`;
    const newKey: ApiKey = {
      id: `k${Date.now()}`, name: newKeyName, key: rawKey,
      created: "Just now", lastUsed: "Never", calls: 0,
      scope: newKeyScopes, status: "active", tier: "Pro",
    };
    setKeys((prev) => [newKey, ...prev]);
    setCreatedKey(rawKey);
    setNewKeyName("");
    setNewKeyScopes(["read"]);
  }

  const scopeOptions = ["read", "write", "batch", "webhook"];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>Manage your API keys. Keep them secret — never commit to public repos.</p>
        </div>
        <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
          onClick={() => { setShowCreate(true); setCreatedKey(null); }}
          className="flex items-center gap-2 bg-[#0d1f26] text-white text-sm font-semibold px-4 py-2.5 rounded-xl hover:bg-[#1a3545] transition-colors"
          style={{ fontFamily: "'Inter', sans-serif" }}>
          <Plus className="w-4 h-4" /> New API Key
        </motion.button>
      </div>

      {/* Create key panel */}
      <AnimatePresence>
        {showCreate && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className="bg-white border-2 border-[#5baab8] rounded-2xl overflow-hidden">
            <div className="p-6">
              {createdKey ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-50 flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Key created successfully</p>
                      <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>Copy it now — you won't be able to see it again.</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 bg-[#0d1f26] rounded-xl px-4 py-3">
                    <code className="flex-1 text-xs text-[#a8d4dc] truncate" style={{ fontFamily: "'DM Mono', monospace" }}>{createdKey}</code>
                    <button onClick={() => copyKey("new", createdKey)} className="text-white/50 hover:text-white transition-colors flex-shrink-0">
                      {copiedId === "new" ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <button onClick={() => setShowCreate(false)} className="text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                    Done — close
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Create New API Key</h3>
                    <button onClick={() => setShowCreate(false)} className="text-muted-foreground hover:text-foreground transition-colors"><X className="w-4 h-4" /></button>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-1.5" style={{ fontFamily: "'Inter', sans-serif" }}>Key name</label>
                    <input value={newKeyName} onChange={(e) => setNewKeyName(e.target.value)}
                      placeholder="e.g. Production App"
                      className="w-full h-10 rounded-xl border border-border bg-[#eef6f8] px-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-[#5baab8] focus:ring-2 focus:ring-[#5baab8]/10 transition-all"
                      style={{ fontFamily: "'Inter', sans-serif" }} />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-foreground mb-2" style={{ fontFamily: "'Inter', sans-serif" }}>Permissions</label>
                    <div className="flex flex-wrap gap-2">
                      {scopeOptions.map((scope) => {
                        const active = newKeyScopes.includes(scope);
                        return (
                          <button key={scope} onClick={() => setNewKeyScopes((prev) => active ? prev.filter((s) => s !== scope) : [...prev, scope])}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${active ? "bg-[#0d1f26] text-white border-[#0d1f26]" : "bg-white text-muted-foreground border-border hover:border-[#5baab8]"}`}
                            style={{ fontFamily: "'DM Mono', monospace" }}>
                            {scope}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={createKey}
                    disabled={!newKeyName.trim()}
                    className="flex items-center gap-2 bg-[#0d1f26] text-white text-sm font-semibold px-5 py-2.5 rounded-xl hover:bg-[#1a3545] transition-colors disabled:opacity-40"
                    style={{ fontFamily: "'Inter', sans-serif" }}>
                    <Sparkles className="w-4 h-4" /> Generate key
                  </motion.button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Keys list */}
      <div className="space-y-3">
        {keys.map((k, i) => (
          <motion.div key={k.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            className={`bg-white border rounded-2xl p-5 transition-all ${k.status === "inactive" ? "opacity-60 border-border" : "border-border hover:border-[#5baab8] hover:shadow-sm"}`}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3 min-w-0">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${k.status === "active" ? "bg-[#d4ecf0]" : "bg-muted"}`}>
                  <Key className={`w-4 h-4 ${k.status === "active" ? "text-[#3d8fa0]" : "text-muted-foreground"}`} />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{k.name}</p>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${k.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-muted text-muted-foreground"}`} style={{ fontFamily: "'DM Mono', monospace" }}>
                      {k.status}
                    </span>
                    <span className="text-[10px] font-bold bg-[#d4ecf0] text-[#3d8fa0] px-2 py-0.5 rounded-full" style={{ fontFamily: "'DM Mono', monospace" }}>{k.tier}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1.5">
                    <code className="text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {visibleKeys.has(k.id) ? k.key : `${k.key.slice(0, 14)}${"•".repeat(16)}`}
                    </code>
                    <button onClick={() => toggleVisible(k.id)} className="text-muted-foreground hover:text-foreground transition-colors">
                      {visibleKeys.has(k.id) ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                    <button onClick={() => copyKey(k.id, k.key)} className="text-muted-foreground hover:text-foreground transition-colors">
                      {copiedId === k.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {k.scope.map((s) => (
                      <span key={s} className="text-[10px] bg-[#eef6f8] text-[#3d8fa0] px-2 py-0.5 rounded font-semibold" style={{ fontFamily: "'DM Mono', monospace" }}>{s}</span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground" title="Rotate key">
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => revokeKey(k.id)} className="p-1.5 rounded-lg hover:bg-red-50 transition-colors text-muted-foreground hover:text-red-600" title="Revoke key">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="flex flex-wrap gap-x-6 gap-y-1 mt-4 pt-4 border-t border-border text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>
              <span>Created: <strong className="text-foreground">{k.created}</strong></span>
              <span>Last used: <strong className="text-foreground">{k.lastUsed}</strong></span>
              <span>Total calls: <strong className="text-foreground">{k.calls.toLocaleString()}</strong></span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Security tip */}
      <div className="flex gap-3 bg-amber-50 border border-amber-200 rounded-xl p-4">
        <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-800 leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}>
          <strong>Security tip:</strong> Never expose API keys in client-side code or public repositories. Use environment variables and rotate keys regularly. IP allowlisting is available on Pro plans.
        </p>
      </div>
    </div>
  );
}

// ─── Downloads Tab ────────────────────────────────────────────────────────────

function DownloadsTab() {
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  const filtered = recentDownloads.filter((d) => {
    const matchFilter = filter === "all" || d.status === filter || d.platform.toLowerCase() === filter;
    const matchSearch = d.platform.toLowerCase().includes(search.toLowerCase()) || d.format.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const barData = [
    { name: "Mon", count: 120 }, { name: "Tue", count: 195 }, { name: "Wed", count: 87 },
    { name: "Thu", count: 240 }, { name: "Fri", count: 320 }, { name: "Sat", count: 195 }, { name: "Sun", count: 145 },
  ];

  return (
    <div className="space-y-5">
      {/* Weekly chart */}
      <motion.div className="bg-white border border-border rounded-2xl p-6"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
        <h3 className="font-bold text-foreground text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Downloads this week</h3>
        <p className="text-xs text-muted-foreground mb-5" style={{ fontFamily: "'Inter', sans-serif" }}>1,302 total · +24% vs last week</p>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={barData} margin={{ top: 0, right: 0, left: -25, bottom: 0 }} barSize={20}>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef6f8" vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#5a7d87", fontFamily: "DM Mono" }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "#5a7d87", fontFamily: "DM Mono" }} tickLine={false} axisLine={false} />
            <Tooltip content={<ChartTooltip />} />
            <Bar dataKey="count" fill="#5baab8" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Filter row */}
      <motion.div className="flex flex-wrap gap-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
        <div className="flex-1 min-w-[180px]">
          <input value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by platform or format…"
            className="w-full h-9 rounded-xl border border-border bg-white px-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-[#5baab8] transition-all"
            style={{ fontFamily: "'Inter', sans-serif" }} />
        </div>
        {["all", "completed", "failed", "processing"].map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${filter === f ? "bg-[#0d1f26] text-white border-[#0d1f26]" : "bg-white text-muted-foreground border-border hover:border-[#5baab8]"}`}
            style={{ fontFamily: "'DM Mono', monospace" }}>
            {f}
          </button>
        ))}
      </motion.div>

      {/* Table */}
      <motion.div className="bg-white border border-border rounded-2xl overflow-hidden"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
        <div className="grid grid-cols-[36px_1fr_80px_70px_90px_80px] text-[10px] font-bold tracking-widest uppercase text-muted-foreground px-5 py-3 bg-[#eef6f8] border-b border-border" style={{ fontFamily: "'DM Mono', monospace" }}>
          <span />
          <span>Source</span>
          <span>Format</span>
          <span>Size</span>
          <span>Status</span>
          <span>Time</span>
        </div>
        <div className="divide-y divide-border">
          {filtered.map((dl, i) => {
            const plt = PLATFORM_ICON_MAP[dl.platform];
            const PIcon = plt?.Icon;
            return (
              <motion.div key={dl.id}
                className="grid grid-cols-[36px_1fr_80px_70px_90px_80px] items-center px-5 py-3.5 hover:bg-[#f7fbfc] transition-colors"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}>
                <div className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: plt ? `${plt.bg}22` : "#5baab815" }}>
                  {PIcon && <PIcon className="w-3.5 h-3.5" style={{ color: plt?.fg === "#fff" ? plt.bg : plt?.fg }} />}
                </div>
                <div className="min-w-0 pr-3">
                  <p className="text-xs font-semibold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{dl.platform}</p>
                  <p className="text-[10px] text-muted-foreground truncate" style={{ fontFamily: "'Inter', sans-serif" }}>{dl.url}</p>
                </div>
                <span className="text-xs font-bold text-[#5baab8]" style={{ fontFamily: "'DM Mono', monospace" }}>{dl.format} {dl.quality}</span>
                <span className="text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>{dl.size}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-block ${
                  dl.status === "completed" ? "bg-emerald-50 text-emerald-700" :
                  dl.status === "failed" ? "bg-red-50 text-red-600" :
                  "bg-[#d4ecf0] text-[#3d8fa0]"}`}
                  style={{ fontFamily: "'DM Mono', monospace" }}>
                  {dl.status}
                </span>
                <span className="text-[10px] text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{dl.time}</span>
              </motion.div>
            );
          })}
          {filtered.length === 0 && (
            <div className="py-12 text-center text-sm text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>No downloads match your filter.</div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

// ─── Billing Tab ──────────────────────────────────────────────────────────────

function BillingTab() {
  const [showCancel, setShowCancel] = useState(false);

  return (
    <div className="space-y-5">
      {/* Current plan card */}
      <motion.div className="bg-[#0d1f26] rounded-2xl p-6 relative overflow-hidden"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
        <motion.div className="absolute -top-16 -right-16 w-48 h-48 rounded-full opacity-20"
          style={{ background: "radial-gradient(circle, #5baab8 0%, transparent 70%)" }}
          animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 8, repeat: Infinity }} />
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-bold text-[#5baab8] bg-[#5baab8]/15 px-3 py-1 rounded-full" style={{ fontFamily: "'DM Mono', monospace" }}>Pro Plan</span>
              <Star className="w-3.5 h-3.5 fill-[#5baab8] text-[#5baab8]" />
            </div>
            <p className="text-4xl font-extrabold text-white mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              $9<span className="text-lg font-normal text-white/50"> / month</span>
            </p>
            <p className="text-sm text-white/60" style={{ fontFamily: "'Inter', sans-serif" }}>Next billing date: February 1, 2025</p>
          </div>
          <div className="flex flex-col gap-2">
            <Link to="/pricing">
              <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                className="w-full flex items-center justify-center gap-2 bg-[#5baab8] hover:bg-[#3d8fa0] text-white font-semibold text-sm px-5 py-2.5 rounded-xl transition-colors"
                style={{ fontFamily: "'Inter', sans-serif" }}>
                <Sparkles className="w-4 h-4" /> Upgrade to Team
              </motion.button>
            </Link>
            <button onClick={() => setShowCancel(!showCancel)} className="text-xs text-white/40 hover:text-white/70 transition-colors text-center" style={{ fontFamily: "'Inter', sans-serif" }}>
              Cancel subscription
            </button>
          </div>
        </div>
        {/* Features on plan */}
        <div className="relative mt-5 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3">
          {["Unlimited downloads", "4K video", "All formats", "200+ platforms"].map((f) => (
            <div key={f} className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#5baab8] flex-shrink-0" />
              <span className="text-xs text-white/60" style={{ fontFamily: "'Inter', sans-serif" }}>{f}</span>
            </div>
          ))}
        </div>
      </motion.div>

      <AnimatePresence>
        {showCancel && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className="bg-red-50 border border-red-200 rounded-2xl overflow-hidden p-5">
            <div className="flex gap-3">
              <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-red-800 text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Cancel Pro subscription?</p>
                <p className="text-xs text-red-700 leading-relaxed mb-3" style={{ fontFamily: "'Inter', sans-serif" }}>
                  You'll keep Pro access until Feb 1, 2025. After that you'll revert to the Free plan (10 downloads/day, 50 platforms).
                </p>
                <div className="flex gap-2">
                  <button className="px-4 py-2 bg-red-600 text-white text-xs font-semibold rounded-lg hover:bg-red-700 transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                    Confirm cancellation
                  </button>
                  <button onClick={() => setShowCancel(false)} className="px-4 py-2 bg-white border border-red-200 text-red-700 text-xs font-semibold rounded-lg hover:bg-red-50 transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
                    Keep Pro
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Payment method */}
      <motion.div className="bg-white border border-border rounded-2xl p-6"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Payment Method</h3>
          <button className="text-xs font-semibold text-[#5baab8] hover:text-[#3d8fa0] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>
            Update
          </button>
        </div>
        <div className="flex items-center gap-4 p-4 bg-[#eef6f8] rounded-xl border border-border">
          <div className="w-12 h-8 bg-[#0d1f26] rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-[10px] font-extrabold text-white tracking-widest" style={{ fontFamily: "'DM Mono', monospace" }}>VISA</span>
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Visa ending in 4242</p>
            <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>Expires 08 / 2027</p>
          </div>
          <span className="text-[10px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full" style={{ fontFamily: "'DM Mono', monospace" }}>Active</span>
        </div>
        <p className="text-xs text-muted-foreground mt-3" style={{ fontFamily: "'Inter', sans-serif" }}>
          Payments processed securely by Stripe. fetchwave never stores your full card details.
        </p>
      </motion.div>

      {/* Billing history */}
      <motion.div className="bg-white border border-border rounded-2xl overflow-hidden"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Billing History</h3>
          <button className="text-xs font-semibold text-[#5baab8] hover:text-[#3d8fa0] transition-colors flex items-center gap-1" style={{ fontFamily: "'Inter', sans-serif" }}>
            <FileText className="w-3.5 h-3.5" /> Download all
          </button>
        </div>
        <div className="divide-y divide-border">
          {invoices.map((inv, i) => (
            <motion.div key={inv.id}
              className="flex items-center justify-between px-6 py-4 hover:bg-[#f7fbfc] transition-colors group"
              initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.06 }}>
              <div className="flex items-center gap-4 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-[#eef6f8] flex items-center justify-center flex-shrink-0">
                  <FileText className="w-4 h-4 text-[#5baab8]" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{inv.desc}</p>
                  <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{inv.date} · {inv.id}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 flex-shrink-0">
                <span className="text-sm font-bold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{inv.amount}</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${inv.status === "paid" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-600"}`} style={{ fontFamily: "'DM Mono', monospace" }}>
                  {inv.status}
                </span>
                <button className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-all">
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

// ─── Settings Tab ─────────────────────────────────────────────────────────────

function SettingsTab() {
  const [notifications, setNotifications] = useState({ jobComplete: true, weeklyReport: true, apiErrors: true, billing: true });
  const [saved, setSaved] = useState(false);

  function save() {
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  }

  return (
    <div className="space-y-5 max-w-2xl">
      {/* Profile */}
      <motion.div className="bg-white border border-border rounded-2xl p-6 space-y-5"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
        <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Profile</h3>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-[#d4ecf0] flex items-center justify-center">
            <span className="text-lg font-bold text-[#0d1f26]">AH</span>
          </div>
          <div>
            <p className="font-semibold text-foreground text-sm mb-0.5" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Avery Hart</p>
            <button className="text-xs font-semibold text-[#5baab8] hover:text-[#3d8fa0] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>Change avatar</button>
          </div>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {[{ label: "Full name", placeholder: "Avery Hart", type: "text" }, { label: "Email address", placeholder: "avery@example.com", type: "email" }].map(({ label, placeholder, type }) => (
            <label key={label} className="block">
              <span className="text-xs font-semibold text-foreground mb-1.5 block" style={{ fontFamily: "'Inter', sans-serif" }}>{label}</span>
              <input type={type} defaultValue={placeholder} className="w-full h-10 rounded-xl border border-border bg-[#eef6f8] px-3 text-sm text-foreground outline-none focus:border-[#5baab8] focus:ring-2 focus:ring-[#5baab8]/10 transition-all" style={{ fontFamily: "'Inter', sans-serif" }} />
            </label>
          ))}
        </div>
      </motion.div>

      {/* Security */}
      <motion.div className="bg-white border border-border rounded-2xl p-6 space-y-4"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}>
        <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Security</h3>
        <div className="flex items-center justify-between p-4 bg-[#eef6f8] rounded-xl">
          <div className="flex items-center gap-3">
            <Lock className="w-4 h-4 text-[#5baab8]" />
            <div>
              <p className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Password</p>
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>Last changed 45 days ago</p>
            </div>
          </div>
          <button className="text-xs font-semibold text-[#5baab8] hover:text-[#3d8fa0] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>Change</button>
        </div>
        <div className="flex items-center justify-between p-4 bg-[#eef6f8] rounded-xl">
          <div className="flex items-center gap-3">
            <Shield className="w-4 h-4 text-[#5baab8]" />
            <div>
              <p className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Two-factor authentication</p>
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>Add an extra layer of security</p>
            </div>
          </div>
          <button className="text-xs font-semibold bg-[#0d1f26] text-white px-3 py-1.5 rounded-lg hover:bg-[#1a3545] transition-colors" style={{ fontFamily: "'Inter', sans-serif" }}>Enable</button>
        </div>
      </motion.div>

      {/* Notifications */}
      <motion.div className="bg-white border border-border rounded-2xl p-6 space-y-4"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.14 }}>
        <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Notifications</h3>
        {[
          { key: "jobComplete" as const, label: "Job complete", desc: "Notify when a download finishes" },
          { key: "weeklyReport" as const, label: "Weekly usage report", desc: "Summary of downloads and API calls" },
          { key: "apiErrors" as const, label: "API error alerts", desc: "Alert when error rate exceeds 5%" },
          { key: "billing" as const, label: "Billing reminders", desc: "Upcoming charges and invoices" },
        ].map(({ key, label, desc }) => (
          <div key={key} className="flex items-center justify-between py-2 border-b border-border last:border-0">
            <div>
              <p className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{label}</p>
              <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>{desc}</p>
            </div>
            <button onClick={() => setNotifications((p) => ({ ...p, [key]: !p[key] }))}
              className={`relative w-11 h-6 rounded-full transition-colors ${notifications[key] ? "bg-[#0d1f26]" : "bg-muted"}`}>
              <motion.span className="absolute top-1 w-4 h-4 rounded-full bg-white shadow"
                animate={{ left: notifications[key] ? 26 : 4 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }} />
            </button>
          </div>
        ))}
      </motion.div>

      {/* Save */}
      <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }} onClick={save}
        className="flex items-center gap-2 bg-[#0d1f26] text-white font-semibold text-sm px-6 py-3 rounded-xl hover:bg-[#1a3545] transition-colors"
        style={{ fontFamily: "'Inter', sans-serif" }}>
        <AnimatePresence mode="wait">
          {saved ? (
            <motion.span key="saved" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
              <Check className="w-4 h-4 text-[#5baab8]" /> Saved!
            </motion.span>
          ) : (
            <motion.span key="save" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2">
              Save changes
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────

export function DashboardPage() {
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar active={activeTab} setActive={setActiveTab} collapsed={collapsed} setCollapsed={setCollapsed} />

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Topbar activeTab={activeTab} />

        {/* Mobile tab bar */}
        <div className="md:hidden flex gap-1 px-4 py-2 bg-white border-b border-border overflow-x-auto">
          {NAV_ITEMS.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveTab(id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${activeTab === id ? "bg-[#0d1f26] text-white" : "text-muted-foreground hover:text-foreground"}`}
              style={{ fontFamily: "'Inter', sans-serif" }}>
              <Icon className="w-3.5 h-3.5" /> {label}
            </button>
          ))}
        </div>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div key={activeTab}
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22 }}>
              {activeTab === "overview" && <OverviewTab />}
              {activeTab === "api-keys" && <ApiKeysTab />}
              {activeTab === "downloads" && <DownloadsTab />}
              {activeTab === "billing" && <BillingTab />}
              {activeTab === "settings" && <SettingsTab />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
